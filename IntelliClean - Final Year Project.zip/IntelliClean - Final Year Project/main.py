#!/usr/bin/env python3
import sys
import os
import hashlib
import time
import json
import threading
import matplotlib
matplotlib.use('Qt5Agg')
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure
import matplotlib.dates as mdates
from matplotlib import cm
import numpy as np
from PyQt5.QtWidgets import QSizePolicy, QComboBox, QGroupBox,QGraphicsDropShadowEffect
from datetime import datetime, timedelta
from PyQt5.QtGui import QPixmap, QImage
from PyQt5.QtCore import Qt
from PyQt5.QtWidgets import (QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
                            QPushButton, QLabel, QFrame, QGridLayout, QScrollArea, QStackedWidget,
                            QFileDialog, QMessageBox, QProgressBar, QDialog, QListWidget, 
                            QListWidgetItem, QAbstractItemView, QInputDialog, QMenu, QAction,QSpinBox ,QFormLayout)
from PyQt5.QtGui import (QIcon, QPixmap, QFont, QColor, QPalette, QPainter)
from PyQt5.QtCore import (Qt, QSize, QRect, pyqtSignal, pyqtSlot, QThread, QObject, QTimer, 
                         QSettings, QStandardPaths)
import sqlite3
from contextlib import contextmanager
import pickle
import spacy
from sklearn.cluster import KMeans
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.preprocessing import StandardScaler

# ======================= Constants =======================
CONFIG_FILE = "intelliclean_config.json"
DEFAULT_SCAN_INTERVAL = 3600  # 1 hour in seconds

# ======================= AI Prioritizer =======================
class AIFilePrioritizer:
    def __init__(self, file_manager):
        self.file_manager = file_manager
        self.model_path = os.path.join(
            QStandardPaths.writableLocation(QStandardPaths.AppDataLocation),
            "ai_prioritizer_model.pkl"
        )
        self.vectorizer_path = os.path.join(
            QStandardPaths.writableLocation(QStandardPaths.AppDataLocation),
            "ai_prioritizer_vectorizer.pkl"
        )
        self.scaler_path = os.path.join(
            QStandardPaths.writableLocation(QStandardPaths.AppDataLocation),
            "ai_prioritizer_scaler.pkl"
        )
        
        # Try to load spaCy model
        try:
            self.nlp = spacy.load('en_core_web_sm')
        except:
            self.nlp = None
            print("spaCy English model not found, using simpler text analysis")
        
        # Load or initialize models
        self.vectorizer = self._load_or_initialize(self.vectorizer_path, TfidfVectorizer(max_features=1000))
        self.scaler = self._load_or_initialize(self.scaler_path, StandardScaler())
        self.model = self._load_or_initialize(self.model_path, KMeans(n_clusters=3, random_state=42))
        
        # Create directory if it doesn't exist
        os.makedirs(os.path.dirname(self.model_path), exist_ok=True)
    
    def _load_or_initialize(self, path, default):
        """Load saved model or initialize new one"""
        try:
            if os.path.exists(path):
                with open(path, 'rb') as f:
                    return pickle.load(f)
        except Exception as e:
            print(f"Error loading model from {path}: {e}")
        return default
    
    def save_models(self):
        """Save trained models to disk"""
        try:
            with open(self.model_path, 'wb') as f:
                pickle.dump(self.model, f)
            with open(self.vectorizer_path, 'wb') as f:
                pickle.dump(self.vectorizer, f)
            with open(self.scaler_path, 'wb') as f:
                pickle.dump(self.scaler, f)
            return True
        except Exception as e:
            print(f"Error saving models: {e}")
            return False
    
    def extract_features(self, file_info):
        """Extract features from file info for AI analysis with consistent feature count"""
        # Initialize with all features set to 0
        features = {
            'days_since_access': 0,
            'access_recency': 0,
            'size_mb': 0,
            'is_document': 0,
            'is_media': 0,
            'is_archive': 0,
            'is_code': 0,
            'content_length': 0,
            'is_personal': 0,
            'is_work': 0,
            'has_content': 0,
            'keywords': ""
        }
        
        # Update with actual values
        now = datetime.now()
        last_access = file_info['last_access']
        days_since_access = (now - last_access).days
        features['days_since_access'] = days_since_access
        features['access_recency'] = 1 / (1 + days_since_access)
        
        features['size_mb'] = file_info['size'] / (1024 * 1024)
        
        ext = file_info.get('ext', '').lower()
        features['is_document'] = int(ext in ['.doc', '.docx', '.pdf', '.txt', '.rtf'])
        features['is_media'] = int(ext in ['.jpg', '.png', '.mp4', '.mov', '.mp3'])
        features['is_archive'] = int(ext in ['.zip', '.rar', '.7z'])
        features['is_code'] = int(ext in ['.py', '.js', '.java', '.cpp', '.h'])
        
        # Add content features
        content_features = self._extract_content_features(file_info['path'], ext)
        features.update(content_features)
    
        return features
    def _read_file_content(self, file_path, ext):
        """Read content from file based on type"""
        try:
            if ext == '.txt':
                with open(file_path, 'r', encoding='utf-8') as f:
                    return f.read()
            # TODO: Add support for other file types (PDF, DOCX, etc.)
            return ""
        except Exception as e:
            print(f"Error reading file {file_path}: {e}")
            return ""
    
    def _extract_content_features(self, file_path, ext):
        """Extract content-based features from file if possible"""
        features = {
            'content_complexity': 0,
            'keywords': "",
            'is_personal': 0,
            'is_work': 0,
            'content_length': 0,
            'has_content': 0
        }
        
        # Skip non-text files immediately
        text_extensions = ['.txt', '.doc', '.docx', '.pdf', '.rtf', '.md', '.csv', '.log']
        if ext.lower() not in text_extensions:
            return features
        
        try:
            content = self._read_file_content(file_path, ext)
            if not content or len(content.strip()) < 50:  # Minimum content length
                return features
                
            features['has_content'] = 1
            features['content_length'] = len(content)
            
            # Simple word-based features as fallback
            words = [word.lower() for word in content.split() 
                    if len(word) > 2 and word.isalpha()]
            
            # Basic keyword detection without NLP
            personal_keywords = {'family', 'friend', 'home', 'personal', 'vacation'}
            work_keywords = {'meeting', 'project', 'deadline', 'client', 'report', 'work'}
            
            personal_count = sum(1 for word in words if word in personal_keywords)
            work_count = sum(1 for word in words if word in work_keywords)
            
            features['is_personal'] = int(personal_count > work_count)
            features['is_work'] = int(work_count > personal_count)
            
            # Use spaCy only if we have meaningful content
            if self.nlp is not None and len(words) > 20:
                try:
                    doc = self.nlp(content)
                    meaningful_words = [
                        token.text.lower() for token in doc
                        if not token.is_stop 
                        and not token.is_punct 
                        and token.is_alpha
                        and len(token.text) > 2
                    ]
                    
                    if meaningful_words:
                        # Update counts with better NLP analysis
                        personal_count = sum(1 for word in meaningful_words 
                                        if word in personal_keywords)
                        work_count = sum(1 for word in meaningful_words 
                                        if word in work_keywords)
                        
                        features['is_personal'] = int(personal_count > work_count)
                        features['is_work'] = int(work_count > personal_count)
                        
                        # Extract meaningful keywords
                        keywords = [
                            token.text for token in doc
                            if token.pos_ in ['NOUN', 'PROPN']
                            and not token.is_stop
                            and len(token.text) > 2
                        ]
                        
                        if keywords:
                            features['keywords'] = " ".join(keywords[:20])
                
                except Exception as e:
                    print(f"Skipping NLP analysis for {file_path}: {str(e)[:100]}")

            # Fallback to simple word-based keywords if no NLP keywords
            if not features['keywords'] and words:
                features['keywords'] = " ".join(words[:20])
                    
        except Exception as e:
            print(f"Error processing file {file_path}: {str(e)[:100]}")
        
        return features

    def train_model(self, file_data):
        """Train the AI model with consistent features"""
        try:
            if not file_data:
                print("No file data available for training")
                return False
            
            features_list = []
            for file_info in file_data.values():
                features_list.append(self.extract_features(file_info))
            
            # Create numerical feature matrix in consistent order
            num_features = [
                'days_since_access', 'access_recency', 'size_mb',
                'is_document', 'is_media', 'is_archive', 'is_code',
                'content_length', 'is_personal', 'is_work', 'has_content'
            ]
            
            numerical_data = []
            for f in features_list:
                numerical_data.append([f[key] for key in num_features])
                
            # Scale numerical features
            X_num = self.scaler.fit_transform(numerical_data)
            
            # Text features - process in chunks if large dataset
            text_data = [f['keywords'] for f in features_list]
            if any(text.strip() for text in text_data):
                try:
                    # Process text in chunks to avoid memory issues
                    chunk_size = 1000
                    X_text_chunks = []
                    for i in range(0, len(text_data), chunk_size):
                        chunk = text_data[i:i+chunk_size]
                        X_text_chunks.append(self.vectorizer.fit_transform(chunk).toarray())
                    
                    X_text = np.vstack(X_text_chunks) if len(X_text_chunks) > 1 else X_text_chunks[0]
                    X = np.hstack([X_num, X_text])
                except ValueError:
                    X = X_num
            else:
                X = X_num
                
            # Train model
            self.model.fit(X)
            self.save_models()
            return True
            
        except Exception as e:
            print(f"Error in model training: {str(e)[:200]}")
            return False
    def _create_feature_matrix(self, features):
        """Create numerical feature matrix from extracted features"""
        # Separate text and numerical features
        text_data = [f['keywords'] for f in features]
        numerical_data = []
        
        # Numerical features to include
        num_features = [
            'days_since_access', 'access_recency', 'size_mb',
            'is_document', 'is_media', 'is_archive', 'is_code',
            'content_length', 'is_personal', 'is_work'
        ]
        
        for f in features:
            numerical_data.append([f.get(key, 0) for key in num_features])
        
        # Vectorize text
        X_text = self.vectorizer.fit_transform(text_data).toarray()
        
        # Scale numerical features
        X_num = self.scaler.fit_transform(numerical_data)
        
        # Combine features
        X = np.hstack([X_num, X_text])
        
        return X
    
    def predict_priority(self, file_info):
        """Predict priority for a single file with consistent features"""
        try:
            # Extract features (will return all 11 numerical features)
            features = self.extract_features(file_info)
            
            # Create numerical feature array in consistent order
            numerical_data = [[
                features['days_since_access'],
                features['access_recency'],
                features['size_mb'],
                features['is_document'],
                features['is_media'],
                features['is_archive'],
                features['is_code'],
                features['content_length'],
                features['is_personal'],
                features['is_work'],
                features['has_content']
            ]]
            
            # Text features
            text_data = [features['keywords']]
            
            # Transform features
            if hasattr(self.vectorizer, 'vocabulary_'):  # Check if fitted
                X_text = self.vectorizer.transform(text_data).toarray()
            else:
                X_text = np.zeros((1, 0))  # Empty array if not fitted
                
            if hasattr(self.scaler, 'scale_'):  # Check if fitted
                X_num = self.scaler.transform(numerical_data)
            else:
                X_num = numerical_data  # Use raw values if not fitted
                
            X = np.hstack([X_num, X_text])
            
            # Predict
            if hasattr(self.model, 'cluster_centers_'):  # Check if fitted
                cluster = self.model.predict(X)[0]
                priorities = ['low', 'medium', 'high']
                return priorities[cluster]
            return self._fallback_priority(file_info['last_access'])
            
        except Exception as e:
            print(f"Error predicting priority: {e}")
            return self._fallback_priority(file_info['last_access'])   
    def _fallback_priority(self, last_access):
        """Fallback time-based priority if AI fails"""
        now = datetime.now()
        days_since_access = (now - last_access).days
        
        if days_since_access < 30:
            return 'high'
        elif days_since_access < 90:
            return 'medium'
        else:
            return 'low'

# ======================= Database Manager =======================
class DatabaseManager:
    def __init__(self, db_path):
        self.db_path = db_path
        self._init_db()
    
    # In DatabaseManager
    @contextmanager
    def _get_cursor(self):
        conn = sqlite3.connect(self.db_path)
        conn.execute("PRAGMA journal_mode=WAL")  # Better concurrency
        cursor = conn.cursor()
        try:
            yield cursor
            conn.commit()
        except Exception as e:
            conn.rollback()
            raise e
        finally:
            conn.close()
    
    def _init_db(self):
        with self._get_cursor() as cursor:
            # Create tables if they don't exist
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS monitored_folders (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    path TEXT UNIQUE NOT NULL,
                    last_scan TIMESTAMP
                )
            """)
            
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS file_metadata (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    path TEXT UNIQUE NOT NULL,
                    name TEXT NOT NULL,
                    ext TEXT,
                    size INTEGER NOT NULL,
                    last_access TIMESTAMP NOT NULL,
                    creation_time TIMESTAMP NOT NULL,
                    modified_time TIMESTAMP NOT NULL,
                    hash TEXT,
                    folder_id INTEGER NOT NULL,
                    FOREIGN KEY(folder_id) REFERENCES monitored_folders(id)
                )
            """)
            
            # Check if old version of file_priorities exists
            cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='file_priorities'")
            table_exists = cursor.fetchone()
            
            if table_exists:
                # Check if the source column exists
                cursor.execute("PRAGMA table_info(file_priorities)")
                columns = [column[1] for column in cursor.fetchall()]
                if 'source' not in columns:
                    # Migrate to new schema
                    cursor.execute("""
                        CREATE TABLE new_file_priorities (
                            file_id INTEGER NOT NULL,
                            priority TEXT NOT NULL,
                            source TEXT DEFAULT 'system',
                            PRIMARY KEY(file_id, priority),
                            FOREIGN KEY(file_id) REFERENCES file_metadata(id)
                        )
                    """)
                    cursor.execute("""
                        INSERT INTO new_file_priorities (file_id, priority, source)
                        SELECT file_id, priority, 'system' FROM file_priorities
                    """)
                    cursor.execute("DROP TABLE file_priorities")
                    cursor.execute("ALTER TABLE new_file_priorities RENAME TO file_priorities")
            else:
                # Create new table
                cursor.execute("""
                    CREATE TABLE file_priorities (
                        file_id INTEGER NOT NULL,
                        priority TEXT NOT NULL,
                        source TEXT DEFAULT 'system',
                        PRIMARY KEY(file_id, priority),
                        FOREIGN KEY(file_id) REFERENCES file_metadata(id)
                    )
                """)
            
            cursor.execute("""
                CREATE INDEX IF NOT EXISTS idx_file_metadata_path ON file_metadata(path)
            """)
            
            cursor.execute("""
                CREATE INDEX IF NOT EXISTS idx_file_metadata_hash ON file_metadata(hash)
            """)
    def get_monitored_folders(self):
        with self._get_cursor() as cursor:
            cursor.execute("SELECT path FROM monitored_folders")
            return [row[0] for row in cursor.fetchall()]
    
    def add_monitored_folder(self, folder_path):
        folder_path = os.path.normpath(folder_path)
        with self._get_cursor() as cursor:
            try:
                cursor.execute(
                    "INSERT INTO monitored_folders (path) VALUES (?)",
                    (folder_path,)
                )
                return True
            except sqlite3.IntegrityError:
                return False
    
    def remove_monitored_folder(self, folder_path):
        folder_path = os.path.normpath(folder_path)
        with self._get_cursor() as cursor:
            cursor.execute(
                "DELETE FROM monitored_folders WHERE path = ?",
                (folder_path,)
            )
            return cursor.rowcount > 0
    
    def save_file_metadata(self, folder_path, file_info):
        folder_path = os.path.normpath(folder_path)
        with self._get_cursor() as cursor:
            # Get folder ID
            cursor.execute("SELECT id FROM monitored_folders WHERE path = ?", (folder_path,))
            folder_id = cursor.fetchone()[0]
            
            # Insert or update file metadata
            cursor.execute("""
                INSERT OR REPLACE INTO file_metadata 
                (path, name, ext, size, last_access, creation_time, modified_time, hash, folder_id)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                file_info["path"],
                file_info["name"],
                file_info["ext"],
                file_info["size"],
                file_info["last_access"].timestamp(),
                file_info["creation_time"].timestamp(),
                file_info["modified_time"].timestamp(),
                file_info["hash"],
                folder_id
            ))
            
            # Get the file ID
            cursor.execute("SELECT id FROM file_metadata WHERE path = ?", (file_info["path"],))
            file_id = cursor.fetchone()[0]
            
            return file_id
    
    def update_file_priority(self, file_id, priority, source='system'):
        with self._get_cursor() as cursor:
            # Delete existing priority for this file
            cursor.execute("DELETE FROM file_priorities WHERE file_id = ?", (file_id,))
            
            # Insert new priority
            cursor.execute(
                "INSERT INTO file_priorities (file_id, priority, source) VALUES (?, ?, ?)",
                (file_id, priority, source)
            )
    
    def get_all_file_metadata(self):
        with self._get_cursor() as cursor:
            cursor.execute("""
                SELECT 
                    path, name, ext, size, last_access, creation_time, modified_time, hash
                FROM file_metadata
            """)
            
            files = []
            for row in cursor.fetchall():
                files.append({
                    "path": row[0],
                    "name": row[1],
                    "ext": row[2],
                    "size": row[3],
                    "last_access": datetime.fromtimestamp(row[4]),
                    "creation_time": datetime.fromtimestamp(row[5]),
                    "modified_time": datetime.fromtimestamp(row[6]),
                    "hash": row[7]
                })
            return files
    
    def get_file_priorities(self):
        with self._get_cursor() as cursor:
            cursor.execute("""
                SELECT m.path, p.priority, p.source
                FROM file_metadata m
                JOIN file_priorities p ON m.id = p.file_id
            """)
            
            priorities = {"high": [], "medium": [], "low": []}
            sources = {"high": [], "medium": [], "low": []}
            
            for row in cursor.fetchall():
                priorities[row[1]].append(row[0])
                sources[row[1]].append(row[2])
            
            return priorities, sources
    
    def update_folder_scan_time(self, folder_path):
        folder_path = os.path.normpath(folder_path)
        with self._get_cursor() as cursor:
            cursor.execute("""
                UPDATE monitored_folders 
                SET last_scan = CURRENT_TIMESTAMP
                WHERE path = ?
            """, (folder_path,))

# ======================= File Manager =======================
class FileManager(QObject):
    scan_complete = pyqtSignal(dict)
    scan_progress = pyqtSignal(int, int)  # current, total
    duplicate_scan_complete = pyqtSignal(list)
    folder_added = pyqtSignal(str)
    folder_removed = pyqtSignal(str)
    ai_training_complete = pyqtSignal(bool)
    
    def __init__(self):
        super().__init__()
        # Initialize database
        db_path = os.path.join(
            QStandardPaths.writableLocation(QStandardPaths.AppDataLocation),
            "intelliclean.db"
        )
        self.config_file = os.path.join(
            QStandardPaths.writableLocation(QStandardPaths.AppDataLocation),
            CONFIG_FILE
        )

        os.makedirs(os.path.dirname(db_path), exist_ok=True)
        self.db = DatabaseManager(db_path)
        
        # Initialize AI prioritizer
        self.ai_prioritizer = AIFilePrioritizer(self)
        
        # Load monitored folders from database
        self.monitored_folders = self.db.get_monitored_folders()
        self.file_data = {}  # Store file metadata
        self.file_priorities = {"high": [], "medium": [], "low": []}
        self.priority_sources = {"high": [], "medium": [], "low": []}  # Track if priority came from AI or system
        self.duplicates = []
        
        # Load existing data from database
        self.load_from_database()
    
    def load_from_database(self):
        """Load file data and priorities from database"""
        self.file_data = {}
        for file_info in self.db.get_all_file_metadata():
            file_info["size_str"] = self._format_size(file_info["size"])
            file_info["last_access_str"] = file_info["last_access"].strftime("%Y-%m-%d %H:%M:%S")
            self.file_data[file_info["path"]] = file_info
        
        self.file_priorities, self.priority_sources = self.db.get_file_priorities()
    def _process_file(self, folder, file_path):
        """Process a single file during scanning"""
        try:
            file_info = self._get_file_info(file_path)
            file_id = self.db.save_file_metadata(folder, file_info)
            
            # Update priorities - first use system priority
            priority = self._determine_priority(file_info["last_access"])
            self.db.update_file_priority(file_id, priority, 'system')
            
            # Update in-memory cache
            self.file_data[file_path] = file_info
            return True
        except Exception as e:
            print(f"Error processing {file_path}: {e}")
            return False
    def load_config(self):
        """Load monitored folders from config file"""
        try:
            if os.path.exists(self.config_file):
                with open(self.config_file, "r") as f:
                    config = json.load(f)
                    self.monitored_folders = config.get("monitored_folders", [])
                    # Verify folders still exist
                    self.monitored_folders = [
                        folder for folder in self.monitored_folders 
                        if os.path.exists(folder)
                    ]
        except Exception as e:
            print(f"Error loading config: {e}")
    
    def save_config(self):
        """Save monitored folders to config file"""
        try:
            with open(self.config_file, "w") as f:
                json.dump({
                    "monitored_folders": self.monitored_folders
                }, f, indent=2)
        except Exception as e:
            print(f"Error saving config: {e}")
    
    def add_monitored_folder(self, folder_path):
        """Add a folder to monitor and scan it"""
        folder_path = os.path.normpath(folder_path)
        if os.path.exists(folder_path) and os.path.isdir(folder_path):
            if self.db.add_monitored_folder(folder_path):
                self.monitored_folders.append(folder_path)
                self.folder_added.emit(folder_path)
                
                # Scan the new folder
                self.scan_folder(folder_path)
                return True
        return False
    def scan_folder(self, folder_path):
        """Scan a single folder and update database"""
        if not os.path.exists(folder_path) or not os.path.isdir(folder_path):
            return False
        
        for root, _, files in os.walk(folder_path):
            for file in files:
                file_path = os.path.join(root, file)
                self._process_file(folder_path, file_path)
        
        # Update folder scan time in database
        self.db.update_folder_scan_time(folder_path)
        return True
    def scan_system(self, force_rescan=False, thread=None):
        if not force_rescan and self.file_data:
            return self._get_current_stats()
        
        # Count files first
        total_files = self._count_total_files(thread)
        if total_files == 0:
            return None
        
        # Process files
        processed_files = 0
        for folder in self.monitored_folders:
            if thread and not thread._is_running:
                return None
            
            for root, _, files in os.walk(folder):
                for file in files:
                    if thread and not thread._is_running:
                        return None
                    
                    file_path = os.path.join(root, file)
                    self._process_file(folder, file_path)
                    processed_files += 1
                    
                    # Update progress every 50 files or 1% of total
                    if processed_files % 50 == 0 or processed_files % max(1, total_files//100) == 0:
                        status = f"Scanning: {file_path[-50:]}"  # Show end of path
                        thread.progress_update.emit(
                            processed_files, 
                            total_files,
                            status
                        )
        
        return self._finalize_scan(thread)

    def _get_current_stats(self):
        """Get current statistics without rescanning"""
        return {
            "total_files": len(self.file_data),
            "duplicates": self._count_duplicates(),
            "unused_files": self._count_unused_files(),
            "potential_savings": self._calculate_potential_savings(),
            "priorities": {
                "high": len(self.file_priorities["high"]),
                "medium": len(self.file_priorities["medium"]),
                "low": len(self.file_priorities["low"])
            }
        }

    def _finalize_scan(self, thread):
        """Finalize the scan process"""
        # Re-categorize files
        self._categorize_files()
        
        # Return summary stats
        return self._get_current_stats()
    def remove_monitored_folder(self, folder_path):
        """Remove a monitored folder"""
        folder_path = os.path.normpath(folder_path)
        if folder_path in self.monitored_folders:
            self.monitored_folders.remove(folder_path)
            self.save_config()
            self.folder_removed.emit(folder_path)
            return True
        return False
    
    def scan_system(self, force_rescan=False, thread=None):
        if not force_rescan and self.file_data:
            return self._get_current_stats()
        
        # Count files first
        total_files = self._count_total_files(thread)
        if total_files == 0:
            return None
        
        # Process files
        processed_files = 0
        for folder in self.monitored_folders:
            if thread and not thread._is_running:
                return None
            
            for root, _, files in os.walk(folder):
                for file in files:
                    if thread and not thread._is_running:
                        return None
                    
                    file_path = os.path.join(root, file)
                    self._process_file(folder, file_path)
                    processed_files += 1
                    
                    # Update progress every 50 files or 1% of total
                    if processed_files % 50 == 0 or processed_files % max(1, total_files//100) == 0:
                        status = f"Scanning: {file_path[-50:]}"  # Show end of path
                        thread.progress_update.emit(
                            processed_files, 
                            total_files,
                            status
                        )
        
        return self._finalize_scan(thread)

    def _count_total_files(self, thread):
        total_files = 0
        for folder in self.monitored_folders:
            if thread and not thread._is_running:
                return 0
            for root, _, files in os.walk(folder):
                total_files += len(files)
                # Update count periodically
                if total_files % 100 == 0:
                    thread.progress_update.emit(0, total_files, "Counting files...")
        return total_files
    def find_duplicates(self, thread=None):
        """Find duplicates with thread support"""
        if not self.file_data:
            if thread is None or thread._is_running:
                self.scan_system(thread=thread)
            
        hash_dict = {}
        duplicates = []
        total_files = len(self.file_data)
        processed_files = 0
        
        for file_path, file_info in self.file_data.items():
            if thread and not thread._is_running:
                return []
                
            file_hash = file_info.get("hash", "")
            if file_hash:
                if file_hash in hash_dict:
                    hash_dict[file_hash].append(file_path)
                else:
                    hash_dict[file_hash] = [file_path]
            
            processed_files += 1
            if thread:
                thread.progress_update.emit(processed_files, total_files, f"Checking duplicates: {file_path[-50:]}")
        
        for file_hash, file_paths in hash_dict.items():
            if thread and not thread._is_running:
                return []
                
            if len(file_paths) > 1:
                duplicates.append({
                    "hash": file_hash,
                    "files": file_paths,
                    "size": self.file_data[file_paths[0]]["size"]
                })
        
        self.duplicates = duplicates
        if thread is None or thread._is_running:
            self.duplicate_scan_complete.emit(duplicates)
        return duplicates

    def train_ai_model(self):
        """Train the AI model on the collected file data"""
        if not self.file_data:
            print("No file data available to train AI model")
            return False
        
        # Create and configure progress dialog
        self.progress_dialog = ProgressDialog(
            "AI Training", 
            "Preparing to train AI model...",
            self.parent() if self.parent() else None
        )
        self.progress_dialog.cancel_btn.clicked.connect(self.cancel_ai_training)
        
        # Create a thread for training
        self.ai_train_thread = AIThread(self.ai_prioritizer, self.file_data)
        
        # Connect signals
        self.ai_train_thread.progress_update.connect(self.progress_dialog.update_progress)
        self.ai_train_thread.status_update.connect(self.progress_dialog.message_label.setText)
        self.ai_train_thread.training_complete.connect(self.on_ai_training_complete)
        self.ai_train_thread.finished.connect(self.cleanup_ai_thread)
        
        # Show dialog and start thread
        self.progress_dialog.show()
        self.ai_train_thread.start()
        return True

    def cancel_ai_training(self):
        """Cancel the ongoing AI training"""
        if hasattr(self, 'ai_train_thread') and self.ai_train_thread.isRunning():
            self.ai_train_thread.stop()
            self.progress_dialog.close()
            
    def cleanup_ai_thread(self):
        """Clean up the AI training thread"""
        if hasattr(self, 'ai_train_thread'):
            self.ai_train_thread.deleteLater()
            del self.ai_train_thread
        if hasattr(self, 'progress_dialog'):
            self.progress_dialog.close()
    def on_ai_training_complete(self, success):
        """Callback when AI training completes"""
        if success:
            print("AI model training completed successfully")
            # Re-prioritize files using AI
            self.apply_ai_priorities()
        else:
            print("AI model training failed")
        
        self.ai_training_complete.emit(success)
    
    def apply_ai_priorities(self):
        """Apply AI-predicted priorities to all files"""
        if not self.file_data:
            return
        
        for file_path, file_info in self.file_data.items():
            try:
                # Get file ID from database
                with self.db._get_cursor() as cursor:
                    cursor.execute("SELECT id FROM file_metadata WHERE path = ?", (file_path,))
                    file_id = cursor.fetchone()[0]
                
                # Predict priority using AI
                ai_priority = self.ai_prioritizer.predict_priority(file_info)
                
                # Update priority in database
                self.db.update_file_priority(file_id, ai_priority, 'ai')
                
            except Exception as e:
                print(f"Error applying AI priority to {file_path}: {e}")
        
        # Reload priorities from database
        self.file_priorities, self.priority_sources = self.db.get_file_priorities()
    
    
    def get_priority_files(self, priority_level):
        """Get files for a specific priority level"""
        return self.file_priorities.get(priority_level, [])
    
    def get_file_info(self, file_path):
        """Get metadata for a specific file"""
        return self.file_data.get(file_path, {})
    
    def _get_file_info(self, file_path):
        """Get metadata for a file"""
        stats = os.stat(file_path)
        last_access = datetime.fromtimestamp(stats.st_atime)
        creation_time = datetime.fromtimestamp(stats.st_ctime)
        modified_time = datetime.fromtimestamp(stats.st_mtime)
        size = stats.st_size
        
        # Calculate file hash for files under 100MB
        file_hash = ""
        if size < 100 * 1024 * 1024:  # 100MB
            file_hash = self._calculate_file_hash(file_path)
        
        return {
            "name": os.path.basename(file_path),
            "path": file_path,
            "ext": os.path.splitext(file_path)[1].lower(),
            "size": size,
            "size_str": self._format_size(size),
            "last_access": last_access,
            "last_access_str": last_access.strftime("%Y-%m-%d %H:%M:%S"),
            "creation_time": creation_time,
            "modified_time": modified_time,
            "hash": file_hash
        }
    
    def _format_size(self, size):
        """Format file size in human-readable format"""
        for unit in ['B', 'KB', 'MB', 'GB', 'TB']:
            if size < 1024.0:
                return f"{size:.1f} {unit}"
            size /= 1024.0
        return f"{size:.1f} PB"
    
    def _calculate_file_hash(self, file_path):
        """Calculate MD5 hash of a file"""
        hash_md5 = hashlib.md5()
        try:
            with open(file_path, "rb") as f:
                for chunk in iter(lambda: f.read(4096), b""):
                    hash_md5.update(chunk)
            return hash_md5.hexdigest()
        except Exception:
            return ""
    
    def _count_duplicates(self):
        """Count how many duplicate files exist"""
        hash_count = {}
        for _, file_info in self.file_data.items():
            file_hash = file_info.get("hash", "")
            if file_hash:
                hash_count[file_hash] = hash_count.get(file_hash, 0) + 1
        
        duplicate_count = 0
        for count in hash_count.values():
            if count > 1:
                duplicate_count += count - 1  # Subtract 1 to count only the duplicates
                
        return duplicate_count
    
    def _count_unused_files(self):
        """Count files that haven't been accessed in the last 6 months"""
        cutoff_date = datetime.now() - timedelta(days=180)
        unused_count = 0
        
        for _, file_info in self.file_data.items():
            if file_info["last_access"] < cutoff_date:
                unused_count += 1
                
        return unused_count
    
    def _calculate_potential_savings(self):
        """Calculate potential disk space that could be freed"""
        # Space from duplicates
        duplicate_space = 0
        hash_dict = {}
        
        # Group files by hash
        for file_path, file_info in self.file_data.items():
            file_hash = file_info.get("hash", "")
            if file_hash:
                if file_hash in hash_dict:
                    hash_dict[file_hash].append(file_path)
                else:
                    hash_dict[file_hash] = [file_path]
        
        # Calculate space used by duplicates
        for file_hash, file_paths in hash_dict.items():
            if len(file_paths) > 1:
                file_size = self.file_data[file_paths[0]]["size"]
                duplicate_space += file_size * (len(file_paths) - 1)
        
        # Convert to GB
        return round(duplicate_space / (1024**3), 2)
    
    def _categorize_files(self):
        """Categorize files into priority levels based on access patterns"""
        now = datetime.now()
        self.file_priorities = {"high": [], "medium": [], "low": []}
        
        for file_path, file_info in self.file_data.items():
            last_access = file_info["last_access"]
            days_since_access = (now - last_access).days
            
            if days_since_access < 30:  # Accessed in the last month
                self.file_priorities["high"].append(file_path)
            elif days_since_access < 90:  # Accessed in the last 3 months
                self.file_priorities["medium"].append(file_path)
            else:
                self.file_priorities["low"].append(file_path)
        
        return self.file_priorities

    def _determine_priority(self, last_access):
        """Determine priority level based on last access time"""
        now = datetime.now()
        days_since_access = (now - last_access).days
        
        if days_since_access < 30:  # Accessed in the last month
            return "high"
        elif days_since_access < 90:  # Accessed in the last 3 months
            return "medium"
        else:
            return "low"

# ======================= Thread Classes =======================
class AIThread(QThread):
    training_complete = pyqtSignal(bool)
    progress_update = pyqtSignal(int, int)  # current, total
    status_update = pyqtSignal(str)  # status messages
    
    def __init__(self, ai_prioritizer, file_data):
        super().__init__()
        self.ai_prioritizer = ai_prioritizer
        self.file_data = file_data
        self._is_running = True
    
    def run(self):
        try:
            self.status_update.emit("Preparing data for AI training...")
            
            # Convert file_data to list for progress tracking
            file_list = list(self.file_data.values())
            total_files = len(file_list)
            
            # Process files in batches with progress updates
            batch_size = 100
            for i in range(0, total_files, batch_size):
                if not self._is_running:
                    self.training_complete.emit(False)
                    return
                
                batch = file_list[i:i+batch_size]
                self.status_update.emit(f"Processing files {i+1}-{min(i+batch_size, total_files)} of {total_files}")
                self.progress_update.emit(i, total_files)
                
                # Process the batch (this is just feature extraction)
                for file_info in batch:
                    self.ai_prioritizer.extract_features(file_info)
            
            self.status_update.emit("Training AI model...")
            success = self.ai_prioritizer.train_model(self.file_data)
            
            self.training_complete.emit(success)
        except Exception as e:
            self.status_update.emit(f"Error in AI training: {str(e)[:200]}")
            self.training_complete.emit(False)
    
    def stop(self):
        self._is_running = False
class ScanThread(QThread):
    progress_update = pyqtSignal(int, int, str)  # current, total, status
    scan_complete = pyqtSignal(dict)
    duplicate_scan_complete = pyqtSignal(list)
    
    def __init__(self, file_manager, force_rescan=False, scan_type="normal"):
        super().__init__()
        self.file_manager = file_manager
        self.force_rescan = force_rescan
        self.scan_type = scan_type
        self._is_running = True
    
    def run(self):
        try:
            if self.scan_type == "duplicates":
                # Perform duplicate scan
                duplicates = self.file_manager.find_duplicates(thread=self)
                if self._is_running:
                    self.duplicate_scan_complete.emit(duplicates)
            else:
                # Perform normal system scan
                result = self.file_manager.scan_system(
                    force_rescan=self.force_rescan,
                    thread=self
                )
                if self._is_running:
                    self.scan_complete.emit(result)
        except Exception as e:
            self.progress_update.emit(0, 0, f"Error: {str(e)}")
    
    def stop(self):
        self._is_running = False

class AnalyticsPage(QWidget):
    def __init__(self, file_manager, parent=None):
        super().__init__(parent)
        self.file_manager = file_manager
        
        # Initialize color palette first
        self.colors = {
            'primary': '#6C5CE7',  # Purple
            'secondary': '#00CEC9',  # Teal
            'accent': '#FD79A8',  # Pink
            'dark': '#2D3436',  # Dark gray
            'light': '#DFE6E9',  # Light gray
            'success': '#00B894',  # Green
            'warning': '#FDCB6E',  # Yellow
            'danger': '#E17055'  # Orange
        }
        
        self.setup_ui()

    def setup_ui(self):
        layout = QVBoxLayout(self)
        self.setStyleSheet("""
            QGroupBox {
                border: 1px solid #DFE6E9;
                border-radius: 8px;
                margin-top: 10px;
                padding-top: 15px;
                font-weight: bold;
                color: #2D3436;
            }
            QComboBox {
                padding: 5px;
                border: 1px solid #DFE6E9;
                border-radius: 4px;
                min-width: 150px;
            }
        """)
        
        # Time range selector
        time_group = QGroupBox("Time Range Selection")
        time_layout = QHBoxLayout()
        self.time_combo = QComboBox()
        self.time_combo.addItems(["Last 7 days", "Last 30 days", "Last 90 days", "Last year", "All time"])
        self.time_combo.currentIndexChanged.connect(self.update_analytics)
        time_layout.addWidget(QLabel("Show data for:"))
        time_layout.addWidget(self.time_combo)
        time_layout.addStretch()
        time_group.setLayout(time_layout)
        
        # Canvas for charts
        self.figure = Figure(figsize=(10, 8), dpi=100)
        self.canvas = FigureCanvas(self.figure)
        self.canvas.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        
        layout.addWidget(time_group)
        layout.addWidget(self.canvas)
        
        # Initial render
        self.update_analytics()

    def update_analytics(self):
        self.figure.clear()
        time_range = self.get_time_range()
        
        # Create grid layout with different sizes
        grid = self.figure.add_gridspec(2, 2)
        
        # Chart 1: File Access Timeline
        ax1 = self.figure.add_subplot(grid[0, 0])
        self.plot_access_timeline(ax1, time_range)
        
        # Chart 2: File Type Distribution
        ax2 = self.figure.add_subplot(grid[0, 1])
        self.plot_file_types(ax2)
        
        # Chart 3: Size Distribution
        ax3 = self.figure.add_subplot(grid[1, 0])
        self.plot_size_distribution(ax3)
        
        # Chart 4: Priority Analysis
        ax4 = self.figure.add_subplot(grid[1, 1])
        self.plot_priority_analysis(ax4, time_range)
        
        self.figure.tight_layout()
        self.canvas.draw()

    def plot_access_timeline(self, ax, time_range):
        if not hasattr(self.file_manager, 'file_data') or not self.file_manager.file_data:
            self.show_no_data(ax)
            return

        dates = []
        for file_info in self.file_manager.file_data.values():
            if 'last_access' in file_info:
                dates.append(file_info['last_access'])
        
        if time_range:
            cutoff = datetime.now() - time_range
            dates = [d for d in dates if d >= cutoff]
        
        if not dates:
            self.show_no_data(ax)
            return
        
        # Plot histogram
        ax.hist(dates, bins=30, color=self.colors['primary'], edgecolor='white')
        
        # Style the plot
        ax.set_facecolor('#F5F6FA')
        ax.grid(True, linestyle='--', alpha=0.6)
        ax.set_title('File Access Timeline', pad=20, fontweight='bold', 
                    color=self.colors['dark'])
        ax.set_xlabel('Date', labelpad=10)
        ax.set_ylabel('Number of Files Accessed', labelpad=10)
        ax.xaxis.set_major_formatter(mdates.DateFormatter('%b %d'))
        self.figure.autofmt_xdate(rotation=45)
        
        # Remove spines
        for spine in ['top', 'right']:
            ax.spines[spine].set_visible(False)

    def plot_file_types(self, ax):
        if not hasattr(self.file_manager, 'file_data') or not self.file_manager.file_data:
            self.show_no_data(ax)
            return

        type_counts = {}
        
        for file_info in self.file_manager.file_data.values():
            ext = file_info.get('ext', '').lower()
            if ext:
                type_counts[ext] = type_counts.get(ext, 0) + 1
        
        if not type_counts:
            self.show_no_data(ax)
            return
        
        # Sort by count descending
        sorted_types = sorted(type_counts.items(), key=lambda x: x[1], reverse=True)
        labels, counts = zip(*sorted_types)
        
        # Create bar chart
        ax.bar(labels, counts, color=self.colors['primary'])
        
        # Style the plot
        ax.set_facecolor('#F5F6FA')
        ax.grid(True, linestyle='--', alpha=0.6)
        ax.set_title('File Type Distribution', pad=20, fontweight='bold', 
                    color=self.colors['dark'])
        ax.set_xlabel('File Type', labelpad=10)
        ax.set_ylabel('Count', labelpad=10)
        ax.tick_params(axis='x', rotation=45)
        
        # Remove spines
        for spine in ['top', 'right']:
            ax.spines[spine].set_visible(False)

    def plot_size_distribution(self, ax):
        if not hasattr(self.file_manager, 'file_data') or not self.file_manager.file_data:
            self.show_no_data(ax)
            return

        sizes = []
        for file_info in self.file_manager.file_data.values():
            if 'size' in file_info:
                sizes.append(file_info['size'])
        
        if not sizes:
            self.show_no_data(ax)
            return
        
        # Create histogram
        ax.hist(sizes, bins=30, color=self.colors['primary'], edgecolor='white')
        
        # Style the plot
        ax.set_facecolor('#F5F6FA')
        ax.grid(True, linestyle='--', alpha=0.6)
        ax.set_title('File Size Distribution', pad=20, fontweight='bold', 
                    color=self.colors['dark'])
        ax.set_xlabel('File Size (bytes)', labelpad=10)
        ax.set_ylabel('Count', labelpad=10)
        
        # Remove spines
        for spine in ['top', 'right']:
            ax.spines[spine].set_visible(False)

    def plot_priority_analysis(self, ax, time_range):
        if not hasattr(self.file_manager, 'file_priorities') or not self.file_manager.file_priorities:
            self.show_no_data(ax)
            return

        priorities = ['high', 'medium', 'low']
        counts = []
        for p in priorities:
            if p in self.file_manager.file_priorities:
                counts.append(len(self.file_manager.file_priorities[p]))
            else:
                counts.append(0)
        
        if sum(counts) == 0:
            self.show_no_data(ax)
            return
        
        # Create bar chart
        colors = [self.colors['success'], self.colors['warning'], self.colors['danger']]
        ax.bar(priorities, counts, color=colors)
        
        # Style the plot
        ax.set_facecolor('#F5F6FA')
        ax.grid(True, linestyle='--', alpha=0.6)
        ax.set_title('File Priority Analysis', pad=20, fontweight='bold', 
                    color=self.colors['dark'])
        ax.set_xlabel('Priority', labelpad=10)
        ax.set_ylabel('Count', labelpad=10)
        
        # Remove spines
        for spine in ['top', 'right']:
            ax.spines[spine].set_visible(False)

    def show_no_data(self, ax):
        ax.set_facecolor('#F5F6FA')
        ax.text(0.5, 0.5, 'No data available', 
               ha='center', va='center', 
               fontsize=12, color=self.colors['dark'])
        ax.set_xticks([])
        ax.set_yticks([])
        for spine in ax.spines.values():
            spine.set_visible(False)

    def get_time_range(self):
        text = self.time_combo.currentText()
        if text == "Last 7 days":
            return timedelta(days=7)
        elif text == "Last 30 days":
            return timedelta(days=30)
        elif text == "Last 90 days":
            return timedelta(days=90)
        elif text == "Last year":
            return timedelta(days=365)
        return None  # All time

# ======================= Icon Provider =======================

class IconProvider:
    """Class to provide icons for the application"""
    
    def __init__(self):
        # Map of icon names to unicode characters (using FontAwesome 4.7)
        self.icon_map = {
            "copy": "\uf0c5",
            "trash": "\uf1f8",
            "clock": "\uf017",
            "hdd": "\uf0a0",
            "folder": "\uf07b",
            "folder-open": "\uf07c",
            "chart": "\uf080",
            "sort": "\uf160",
            "search": "\uf002",
            "settings": "\uf013",
            "moon": "\uf186",
            "sun": "\uf185",
            "twitter": "\uf099",
            "facebook": "\uf39e",
            "linkedin": "\uf0e1",
            "github": "\uf09b",
            "file": "\uf15b",
            "image": "\uf1c5",
            "video": "\uf1c8",
            "audio": "\uf1c7",
            "archive": "\uf1c6",
            "code": "\uf1c9",
            "doc": "\uf1c2",
            "pdf": "\uf1c1",
            "spinner": "\uf110",
            "check": "\uf00c",
            "times": "\uf00d",
            "info": "\uf129",
            "warning": "\uf071",
            "question": "\uf128",
            "cog": "\uf013",
            "refresh": "\uf021",
            "plus": "\uf067",
            "minus": "\uf068",
            "star": "\uf005",
            "heart": "\uf004",
            "thumbs-up": "\uf164",
            "thumbs-down": "\uf165",
            "eye": "\uf06e",
            "eye-slash": "\uf070",
            "lock": "\uf023",
            "unlock": "\uf09c",
            "user": "\uf007",
            "users": "\uf0c0",
            "home": "\uf015",
            "database": "\uf1c0",
            "cloud": "\uf0c2",
            "download": "\uf019",
            "upload": "\uf093",
            "sync": "\uf021",
            "history": "\uf1da",
            "calendar": "\uf073",
            "tag": "\uf02b",
            "tags": "\uf02c",
            "bookmark": "\uf02e",
            "edit": "\uf044",
            "save": "\uf0c7",
            "ban": "\uf05e",
            "filter": "\uf0b0",
            "camera": "\uf030",
            "bell": "\uf0f3",
            "inbox": "\uf01c",
            "flag": "\uf024",
            "fire": "\uf06d",
            "bolt": "\uf0e7",
            "shield": "\uf132",
            "trophy": "\uf091",
            "rocket": "\uf135",
            "bug": "\uf188",
            "key": "\uf084",
            "lightbulb": "\uf0eb",
            "magic": "\uf0d0",
            "puzzle": "\uf12e",
            "terminal": "\uf120",
            "external-link": "\uf08e",
        }
    
    def get_icon(self, icon_name, color="#4a6bff", bg_color="transparent", size=24):
        """Get a QIcon for the given name"""
        pixmap = self.get_pixmap(icon_name, color, bg_color, size)
        return QIcon(pixmap)
    
    def get_pixmap(self, icon_name, color=None, bg_color="transparent", size=24):
        """Get a QPixmap for the given name"""
        pixmap = QPixmap(size, size)
        pixmap.fill(Qt.transparent)
        
        painter = QPainter(pixmap)
        painter.setRenderHint(QPainter.Antialiasing)
        
        # If background color is not transparent
        if bg_color != "transparent":
            painter.setBrush(QColor(bg_color))
            painter.setPen(Qt.NoPen)
            painter.drawEllipse(0, 0, size, size)
        
        # Determine color based on theme if not specified
        if color is None:
            # Get the parent widget's style
            parent = self.parent() if hasattr(self, 'parent') else None
            if parent and parent.property("class") == "dark":
                color = "#e6e8ee"  # Light color for dark theme
            else:
                color = "#333333"  # Dark color for light theme
        
        # Set up for drawing the icon
        painter.setPen(QColor(color))
        
        # Use FontAwesome if available, otherwise use a simple character
        try:
            font = QFont("FontAwesome", int(size * 0.6))
            painter.setFont(font)
            
            # Draw the icon character
            character = self.icon_map.get(icon_name, "?")
            painter.drawText(QRect(0, 0, size, size), Qt.AlignCenter, character)
        except Exception:
            # Fallback if FontAwesome is not available
            font = QFont("Arial", int(size * 0.5))
            painter.setFont(font)
            
            # Just draw the first character of the icon name as fallback
            character = icon_name[0].upper() if icon_name else "?"
            painter.drawText(QRect(0, 0, size, size), Qt.AlignCenter, character)
        
        painter.end()
        return pixmap

# ======================= Custom Widgets =======================
class IconButton(QPushButton):
    def __init__(self, icon_name=None, size=24, parent=None):
        super().__init__(parent)
        self.icon_provider = IconProvider()
        self.size = size
        self.setFixedSize(size, size)
        
        if icon_name:
            self.set_icon(icon_name)
    
    def set_icon(self, icon_name):
        self.setIcon(self.icon_provider.get_icon(icon_name))
        self.setIconSize(QSize(int(self.size * 0.6), int(self.size * 0.6)))

class StatCard(QFrame):
    def __init__(self, icon_name, title, number, description, parent=None):
        super().__init__(parent)
        # Drop shadow for 3D elevation effect
        shadow = QGraphicsDropShadowEffect(self)
        shadow.setBlurRadius(25)
        shadow.setXOffset(0)
        shadow.setYOffset(6)
        shadow.setColor(QColor(0, 0, 0, 30))
        self.setGraphicsEffect(shadow)

        self.setObjectName("statCard")
        
        layout = QHBoxLayout(self)
        layout.setContentsMargins(20, 20, 20, 20)
        
        # Icon
        self.icon_frame = QFrame()
        self.icon_frame.setObjectName("statIcon")
        self.icon_frame.setFixedSize(50, 50)
        
        icon_layout = QVBoxLayout(self.icon_frame)
        icon_layout.setAlignment(Qt.AlignCenter)
        
        icon_provider = IconProvider()
        icon = QLabel()
        if os.path.isfile(icon_name):
            pixmap = QPixmap(icon_name)
            icon.setPixmap(pixmap.scaled(60, 60, Qt.KeepAspectRatio, Qt.SmoothTransformation))
        else:
            icon.setPixmap(icon_provider.get_pixmap(icon_name, color="#ffffff", size=80))
        icon.setAlignment(Qt.AlignCenter)
        icon_layout.addWidget(icon)
        
        # Info section
        info_layout = QVBoxLayout()
        info_layout.setSpacing(2)
        
        self.title_label = QLabel(title)
        self.title_label.setObjectName("statTitle")
        self.title_label.setAttribute(Qt.WA_TranslucentBackground)  # Important for transparency
        self.title_label.setStyleSheet("background-color: transparent;")
        
        self.number_label = QLabel(number)
        self.number_label.setObjectName("statNumber")
        
        self.desc_label = QLabel(description)
        self.desc_label.setObjectName("statDesc")
        
        info_layout.addWidget(self.title_label)
        info_layout.addWidget(self.number_label)
        info_layout.addWidget(self.desc_label)
        
        layout.addWidget(self.icon_frame)
        layout.addLayout(info_layout)
    
    def update_data(self, number, description=None):
        self.number_label.setText(number)
        if description:
            self.desc_label.setText(description)

class PriorityCard(QFrame):
    def __init__(self, level, title, count, fill_percent, description, parent=None):
        super().__init__(parent)
        self.setObjectName(f"priorityCard")
        self.level = level
        
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)
        
        # Header
        header = QFrame()
        header.setObjectName(f"priorityHeader{level.capitalize()}")
        header.setMinimumHeight(60)
        
        header_layout = QHBoxLayout(header)
        
        header_title = QLabel(title)
        header_title.setObjectName("priorityHeaderTitle")
        
        self.file_count = QLabel(count)
        self.file_count.setObjectName("priorityFileCount")
        
        header_layout.addWidget(header_title)
        header_layout.addStretch()
        header_layout.addWidget(self.file_count)
        
        # Content
        content = QFrame()
        content.setObjectName("priorityContent")
        
        content_layout = QVBoxLayout(content)
        content_layout.setContentsMargins(20, 20, 20, 20)
        
        # Chart
        chart_frame = QFrame()
        chart_frame.setObjectName("priorityChart")
        chart_frame.setMinimumHeight(10)
        chart_frame.setMaximumHeight(10)
        
        chart_layout = QHBoxLayout(chart_frame)
        chart_layout.setContentsMargins(0, 0, 0, 0)
        
        self.chart_fill = QFrame()
        self.chart_fill.setObjectName(f"chartFill{level.capitalize()}")
        self.chart_fill.setMinimumWidth(int(fill_percent * 2))
        
        chart_layout.addWidget(self.chart_fill)
        chart_layout.addStretch()
        
        self.description_label = QLabel(description)
        self.description_label.setAlignment(Qt.AlignCenter)
        
        self.view_btn = QPushButton("View Files")
        self.view_btn.setObjectName("priorityBtn")
        
        content_layout.addWidget(chart_frame)
        content_layout.addSpacing(10)
        content_layout.addWidget(self.description_label)
        content_layout.addSpacing(10)
        content_layout.addWidget(self.view_btn)
        
        # Add components to card
        layout.addWidget(header)
        layout.addWidget(content)
    
    def update_data(self, count, fill_percent):
        self.file_count.setText(count)
        self.chart_fill.setMinimumWidth(int(fill_percent * 2))

class FeatureCard(QFrame):
    def __init__(self, icon_path, title, description, parent=None):
        super().__init__(parent)
        self.setObjectName("featureCard")
        
        layout = QVBoxLayout(self)
        layout.setAlignment(Qt.AlignCenter)
        
        # Icon setup
        icon_frame = QFrame()
        icon_frame.setObjectName("featureIcon")
        icon_frame.setFixedSize(70, 70)
        
        icon_layout = QVBoxLayout(icon_frame)
        icon_layout.setAlignment(Qt.AlignCenter)
        
        icon = QLabel()
        pixmap = self.load_transparent_icon(icon_path, ignore_color="#FFFFFF")  # Remove white background
        icon.setPixmap(pixmap)
        icon.setAlignment(Qt.AlignCenter)
        icon_layout.addWidget(icon)
        
        # Title and description (unchanged)
        title_label = QLabel(title)
        title_label.setObjectName("featureTitle")
        title_label.setAlignment(Qt.AlignCenter)
        
        desc_label = QLabel(description)
        desc_label.setObjectName("featureDesc")
        desc_label.setAlignment(Qt.AlignCenter)
        desc_label.setWordWrap(True)
        
        layout.addWidget(icon_frame, 0, Qt.AlignCenter)
        layout.addWidget(title_label)
        layout.addWidget(desc_label)
    
    def load_transparent_icon(self, path, ignore_color="#FFFFFF"):
        """Loads an icon and removes a solid background color (e.g., white)."""
        image = QImage(path)
        if image.isNull():
            return QPixmap()  # Return empty if loading fails
        
        # Make the specified color transparent
        image.convertTo(QImage.Format_ARGB32)
        for x in range(image.width()):
            for y in range(image.height()):
                color = image.pixelColor(x, y)
                if color.name() == ignore_color:
                    image.setPixelColor(x, y, Qt.transparent)
        
        pixmap = QPixmap.fromImage(image)
        return pixmap.scaled(48, 48, Qt.KeepAspectRatio, Qt.SmoothTransformation)

class ActionCard(QFrame):
    def __init__(self, icon_path, title, description, button_text, parent=None):
        super().__init__(parent)
        self.setObjectName("actionCard")
        
        layout = QVBoxLayout(self)
        layout.setAlignment(Qt.AlignCenter)
        
        # Icon
        icon_frame = QFrame()
        icon_frame.setObjectName("actionIcon")
        icon_frame.setFixedSize(70, 70)
        
        icon_layout = QVBoxLayout(icon_frame)
        icon_layout.setAlignment(Qt.AlignCenter)
        
        # Load icon from file path
        icon_label = QLabel()
        pixmap = QPixmap(icon_path)
        if not pixmap.isNull():
            # Scale the icon while maintaining aspect ratio
            pixmap = pixmap.scaled(35, 35, Qt.KeepAspectRatio, Qt.SmoothTransformation)
            icon_label.setPixmap(pixmap)
        else:
            print(f"Warning: Could not load icon from {icon_path}")
        
        icon_label.setAlignment(Qt.AlignCenter)
        icon_layout.addWidget(icon_label)
        
        # Title and description
        title_label = QLabel(title)
        title_label.setObjectName("actionTitle")
        title_label.setAlignment(Qt.AlignCenter)
        
        desc_label = QLabel(description)
        desc_label.setObjectName("actionDesc")
        desc_label.setAlignment(Qt.AlignCenter)
        desc_label.setWordWrap(True)
        
        self.action_btn = QPushButton(button_text)
        self.action_btn.setObjectName("actionBtn")
        
        layout.addWidget(icon_frame, 0, Qt.AlignCenter)
        layout.addWidget(title_label)
        layout.addWidget(desc_label)
        layout.addWidget(self.action_btn)

class ProgressDialog(QDialog):
    def __init__(self, title, message, parent=None):
        super().__init__(parent)
        self.setWindowTitle(title)
        self.setMinimumWidth(450)
        self.setModal(True)
        
        layout = QVBoxLayout(self)
        layout.setContentsMargins(20, 20, 20, 20)
        
        self.message_label = QLabel(message)
        self.message_label.setWordWrap(True)
        
        self.progress_bar = QProgressBar()
        self.progress_bar.setRange(0, 100)
        
        self.details_label = QLabel()
        self.details_label.setWordWrap(True)
        
        self.cancel_btn = QPushButton("Cancel")
        self.cancel_btn.clicked.connect(self.reject)
        
        layout.addWidget(self.message_label)
        layout.addWidget(self.progress_bar)
        layout.addWidget(self.details_label)
        layout.addWidget(self.cancel_btn)
        
        self.setAttribute(Qt.WA_DeleteOnClose)
    
    def update_progress(self, current, total, status=""):
        percent = int((current / max(1, total)) * 100)
        self.progress_bar.setValue(percent)
        self.details_label.setText(
            f"Processed: {current}/{total} files\n"
            f"Progress: {percent}%\n"
            f"{status}"
        )
        QApplication.processEvents()
    
    def closeEvent(self, event):
        self.reject()
        super().closeEvent(event)

    def update_status(self, message):
        """Update the status message in the dialog"""
        self.message_label.setText(message)
        QApplication.processEvents()

class FileListWidget(QListWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setSelectionMode(QAbstractItemView.ExtendedSelection)
        self.setContextMenuPolicy(Qt.CustomContextMenu)
        self.customContextMenuRequested.connect(self.show_context_menu)
        self.setStyleSheet("""
            QListWidget {
                border: 1px solid #e6e8ee;
                border-radius: 5px;
                padding: 5px;
                background-color: white;
            }
            QListWidget::item {
                padding: 8px;
                border-bottom: 1px solid #f0f0f0;
            }
            QListWidget::item:hover {
                background-color: #f8f9fd;
            }
            QListWidget::item:selected {
                background-color: #e6f0ff;
                color: #333333;
            }
        """)
    
    def show_context_menu(self, position):
        menu = QMenu()
        
        open_action = QAction("Open File", self)
        open_action.triggered.connect(self.open_selected_file)
        menu.addAction(open_action)
        
        show_in_folder_action = QAction("Show in Folder", self)
        show_in_folder_action.triggered.connect(self.show_in_folder)
        menu.addAction(show_in_folder_action)
        
        delete_action = QAction("Delete", self)
        delete_action.triggered.connect(self.delete_selected_files)
        menu.addAction(delete_action)
        
        menu.exec_(self.viewport().mapToGlobal(position))
    
    def open_selected_file(self):
        selected_items = self.selectedItems()
        if selected_items:
            file_path = selected_items[0].data(Qt.UserRole)
            try:
                if sys.platform == "win32":
                    os.startfile(file_path)
                elif sys.platform == "darwin":
                    os.system(f"open '{file_path}'")
                else:
                    os.system(f"xdg-open '{file_path}'")
            except Exception as e:
                QMessageBox.warning(self, "Error", f"Could not open file: {e}")
    
    def show_in_folder(self):
        selected_items = self.selectedItems()
        if selected_items:
            file_path = selected_items[0].data(Qt.UserRole)
            try:
                if sys.platform == "win32":
                    os.startfile(os.path.dirname(file_path))
                elif sys.platform == "darwin":
                    os.system(f"open '{os.path.dirname(file_path)}'")
                else:
                    os.system(f"xdg-open '{os.path.dirname(file_path)}'")
            except Exception as e:
                QMessageBox.warning(self, "Error", f"Could not open folder: {e}")
    
    def delete_selected_files(self):
        selected_items = self.selectedItems()
        if not selected_items:
            return
            
        reply = QMessageBox.question(
            self, 
            "Confirm Deletion",
            f"Are you sure you want to delete {len(selected_items)} file(s)?",
            QMessageBox.Yes | QMessageBox.No,
            QMessageBox.No
        )
        
        if reply == QMessageBox.Yes:
            for item in selected_items:
                file_path = item.data(Qt.UserRole)
                try:
                    os.remove(file_path)
                    self.takeItem(self.row(item))
                except Exception as e:
                    QMessageBox.warning(self, "Error", f"Could not delete {file_path}: {e}")

# ======================= Main Application =======================
class IntelliCleanUI(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("IntelliClean - Smart Digital Decluttering")
        self.setMinimumSize(1200, 800)
        
        # Initialize components
        self.file_manager = FileManager()
        self.icon_provider = IconProvider()
        self.is_dark_theme = False
        self.current_priority_view = None
        self.current_duplicates = []
        
        # Set up the UI
        self.init_ui()
        self.connect_signals()
        
        # Load icons
        self.load_icons()
        
        # Apply initial stylesheet
        self.apply_stylesheet()
        
        # Start initial scan if we have monitored folders
        if self.file_manager.monitored_folders:
            QTimer.singleShot(1000, self.start_system_scan)
    
    def init_ui(self):
        # Create main widget and layout
        main_widget = QWidget()
        self.setCentralWidget(main_widget)
        main_layout = QVBoxLayout(main_widget)
        main_layout.setContentsMargins(0, 0, 0, 0)
        main_layout.setSpacing(0)
        
        # Create header
        self.setup_header()
        main_layout.addWidget(self.header_frame)
        
        # Create stacked widget for different pages
        self.stacked_widget = QStackedWidget()
        
        # Create dashboard page
        self.dashboard_page = QWidget()
        self.setup_dashboard_page()
        self.stacked_widget.addWidget(self.dashboard_page)
        
        # Create files page
        self.files_page = QWidget()
        self.setup_files_page()
        self.stacked_widget.addWidget(self.files_page)
        
        # Create analytics page
        self.analytics_page = AnalyticsPage(self.file_manager)
        self.stacked_widget.addWidget(self.analytics_page)
        
        # Create settings page
        self.settings_page = QWidget()
        self.setup_settings_page()
        self.stacked_widget.addWidget(self.settings_page)
        
        main_layout.addWidget(self.stacked_widget)
        
        # Create footer
        self.setup_footer()
        main_layout.addWidget(self.footer_frame)

    def start_system_scan(self):
        if not self.file_manager.monitored_folders:
            QMessageBox.warning(
                self, 
                "No Folders Selected", 
                "Please select folders to scan first."
            )
            self.select_folders()
            return
        
        if self.file_manager.file_data:
            reply = QMessageBox.question(
                self,
                "Rescan System?",
                "File data already exists. Would you like to rescan all folders?",
                QMessageBox.Yes | QMessageBox.No,
                QMessageBox.No
            )
            force_rescan = (reply == QMessageBox.Yes)
        else:
            force_rescan = True
        
        self.progress_dialog = ProgressDialog("System Scan", "Preparing to analyze files...", self)
        self.progress_dialog.cancel_btn.clicked.connect(self.cancel_scan)
        
        self.scan_thread = ScanThread(self.file_manager, force_rescan)
        
        # Connect signals - only use progress_update
        self.scan_thread.progress_update.connect(self.progress_dialog.update_progress)
        self.scan_thread.scan_complete.connect(self.on_scan_complete)
        self.scan_thread.finished.connect(self.cleanup_scan_thread)
        
        # Show dialog and start thread
        self.progress_dialog.show()
        self.scan_thread.start()
    def closeEvent(self, event):
        """Handle window close event to clean up threads"""
        # Cancel any ongoing scans
        if hasattr(self, 'scan_thread') and self.scan_thread.isRunning():
            self.scan_thread.stop()
            self.scan_thread.wait(2000)  # Wait up to 2 seconds for thread to finish
        
        if hasattr(self, 'duplicate_thread') and self.duplicate_thread.isRunning():
            self.duplicate_thread.stop()
            self.duplicate_thread.wait(2000)
        
        if hasattr(self, 'ai_train_thread') and self.ai_train_thread.isRunning():
            self.ai_train_thread.stop()
            self.ai_train_thread.wait(2000)
        
        event.accept()
    def setup_header(self):
        self.header_frame = QFrame()
        self.header_frame.setObjectName("headerFrame")
        self.header_frame.setMinimumHeight(80)
        self.header_frame.setMaximumHeight(80)
        
        header_layout = QHBoxLayout(self.header_frame)
        header_layout.setContentsMargins(20, 0, 20, 0)
        
        # Logo container
        logo_container = QWidget()
        logo_layout = QHBoxLayout(logo_container)
        logo_layout.setContentsMargins(0, 0, 0, 0)
        def apply_shadow(widget):
            shadow = QGraphicsDropShadowEffect()
            shadow.setBlurRadius(15)
            shadow.setOffset(0, 3)
            shadow.setColor(QColor(0, 0, 0, 60))
            widget.setGraphicsEffect(shadow)
        logo = QLabel()
        try:
            logo_pixmap = QPixmap("images/intelliclean-logo.png")
            logo.setPixmap(logo_pixmap.scaled(150, 150, Qt.KeepAspectRatio, Qt.SmoothTransformation))
        except Exception:
            # Fallback if logo not found
            logo.setText("IC")
            logo.setStyleSheet("font-weight: bold; font-size: 18px; color: white; background-color: transparent; border-radius: 20px;")
            logo.setAlignment(Qt.AlignCenter)
            logo.setFixedSize(150, 150)
        
        
        logo_layout.addWidget(logo)

        # Navigation
        nav_container = QWidget()
        nav_layout = QHBoxLayout(nav_container)
        nav_layout.setContentsMargins(0, 0, 0, 0)
        nav_layout.setSpacing(10)
        
        nav_items = [
            {"text": "Dashboard", "page_index": 0},
            {"text": "Files", "page_index": 1},
            {"text": "Analytics", "page_index": 2},
            {"text": "Settings", "page_index": 3}
        ]
        
        self.nav_buttons = []
        for item in nav_items:
            btn = QPushButton(item["text"])
            btn.setObjectName("navButton")
            btn.setSizePolicy(QSizePolicy.Preferred, QSizePolicy.Fixed)
            apply_shadow(btn)
            btn.page_index = item["page_index"]
            btn.clicked.connect(lambda checked, b=btn: self.nav_button_clicked(b))
            self.nav_buttons.append(btn)
            nav_layout.addWidget(btn)

        
        self.nav_buttons[0].setProperty("active", True)
        
        # Controls container
        controls_container = QWidget()
        controls_layout = QHBoxLayout(controls_container)
        controls_layout.setContentsMargins(0, 0, 0, 0)
        controls_layout.setSpacing(15)
        
        # Theme toggle button
        self.theme_btn = QPushButton()
        self.theme_btn.setObjectName("themeToggle")
        self.theme_btn.setFixedSize(40, 40)
        self.theme_btn.setIconSize(QSize(32, 32))

        # Start with dark icon (moon), indicating current theme is light
        self.theme_btn.setIcon(QIcon("images/toggle-icon-dark.png"))

        self.theme_btn.clicked.connect(self.toggle_theme)
        # User profile
        user_profile = QLabel()
        try:
            profile_pixmap = QPixmap("images/user-avatar.png")
            user_profile.setPixmap(profile_pixmap.scaled(40, 40, Qt.KeepAspectRatio, Qt.SmoothTransformation))
        except Exception:
            # Fallback if avatar not found
            user_profile.setText("U")
            user_profile.setStyleSheet("font-weight: bold; font-size: 16px; color: white; background-color: #4a6bff; border-radius: 20px;")
            user_profile.setAlignment(Qt.AlignCenter)
            user_profile.setFixedSize(40, 40)
        
        user_profile.setObjectName("userProfile")
        
        controls_layout.addWidget(self.theme_btn)
        controls_layout.addWidget(user_profile)
        
        # Add all components to header
        header_layout.addWidget(logo_container)
        header_layout.addStretch()
        header_layout.addWidget(nav_container)
        header_layout.addStretch()
        header_layout.addWidget(controls_container)
    
    def setup_dashboard_page(self):
        # Create a scroll area for the dashboard
        scroll_area = QScrollArea()
        scroll_area.setWidgetResizable(True)
        scroll_area.setFrameShape(QFrame.NoFrame)
        
        content_widget = QWidget()
        content_layout = QVBoxLayout(content_widget)
        content_layout.setContentsMargins(30, 30, 30, 30)
        content_layout.setSpacing(40)
        
        # Funky Banner Section
        banner_frame = QFrame()
        banner_layout = QVBoxLayout(banner_frame)
        banner_layout.setAlignment(Qt.AlignCenter)

        banner = QLabel()
        # banner.setPixmap(QPixmap("images/hero-banner.png").scaled(1000, 250, Qt.KeepAspectRatio, Qt.SmoothTransformation))
        # banner.setAlignment(Qt.AlignCenter)

        headline = QLabel("Meet Your Digital Cleanup Hero 💫")
        headline.setObjectName("welcomeTitle")
        headline.setAlignment(Qt.AlignCenter)

        tagline = QLabel("IntelliClean identifies duplicates, clears clutter, and saves space—automatically.")
        tagline.setObjectName("welcomeSubtitle")
        tagline.setAlignment(Qt.AlignCenter)

        banner_layout.addWidget(banner)
        banner_layout.addSpacing(15)
        banner_layout.addWidget(headline)
        banner_layout.addWidget(tagline)

        content_layout.addWidget(banner_frame)

        
        # Stats section
        self.stats_frame = QFrame()
        self.stats_layout = QGridLayout(self.stats_frame)
        self.stats_layout.setContentsMargins(40, 20, 40, 20)  # Left, Top, Right, Bottom
        self.stats_layout.setHorizontalSpacing(30)
        self.stats_layout.setVerticalSpacing(20)
        self.stats_layout.setContentsMargins(0, 0, 0, 0)
        self.stats_layout.setSpacing(15)
        
        # Initial stats
        stats_data = [
            {"icon": "images/duplicate-files.png", "title": "Duplicates", "number": "0", "desc": "files found"},
            {"icon": "images/unused-files.png", "title": "Unused Files", "number": "0", "desc": "files identified"},
            {"icon": "images/space-saving-files.png", "title": "Space Savings", "number": "0 GB", "desc": "potential"},
            {"icon": "images/monitored-files.png", "title": "Monitored", "number": "0", "desc": "files total"}
        ]

        
        self.stat_cards = []
        for i, stat in enumerate(stats_data):
            card = StatCard(stat["icon"], stat["title"], stat["number"], stat["desc"])
            self.stat_cards.append(card)
            self.stats_layout.addWidget(card, 0, i)
        
        content_layout.addWidget(self.stats_frame)
        
        # Priority section
        priority_section = QFrame()
        priority_layout = QVBoxLayout(priority_section)
        priority_layout.setContentsMargins(0, 0, 0, 0)
        
        priority_title = QLabel("File Priority Overview")
        priority_title.setObjectName("sectionTitle")
        priority_layout.addWidget(priority_title)
        
        priority_container = QWidget()
        priority_container_layout = QHBoxLayout(priority_container)
        priority_container_layout.setContentsMargins(0, 20, 0, 0)
        priority_container_layout.setSpacing(15)
        
        # Priority cards
        self.priority_cards = {
            "high": PriorityCard("high", "High Priority", "0 files", 0, "Files you frequently access"),
            "medium": PriorityCard("medium", "Medium Priority", "0 files", 0, "Occasionally accessed files"),
            "low": PriorityCard("low", "Low Priority", "0 files", 0, "Rarely or never accessed files")
        }
        
        for level, card in self.priority_cards.items():
            priority_container_layout.addWidget(card)
            # Use level parameter to avoid lambda capture issues
            card.view_btn.clicked.connect(lambda checked, level=level: self.show_priority_files(level))
        
        priority_layout.addWidget(priority_container)
        content_layout.addWidget(priority_section)
        
        # Features section
        features_section = QFrame()
        features_layout = QVBoxLayout(features_section)
        features_layout.setContentsMargins(0, 0, 0, 0)

        features_title = QLabel("Key Features")
        features_title.setObjectName("sectionTitle")
        features_layout.addWidget(features_title)

        features_grid = QGridLayout()
        features_grid.setContentsMargins(0, 20, 0, 0)
        features_grid.setSpacing(15)

        # Feature data - now with proper image paths
        feature_data = [
            {"icon": "images/feature_card/duplicate_detection.png", "title": "Duplicate Detection", "desc": "Automatically find and organize duplicate files across your system."},
            {"icon": "images/feature_card/smart_deletion.png", "title": "Smart Deletion", "desc": "Get intelligent suggestions for files that can be safely removed."},
            {"icon": "images/feature_card/real_time_tracking.png", "title": "Real-Time Monitoring", "desc": "Track file access patterns to optimize your digital workspace."},
            {"icon": "images/feature_card/priority_check.png", "title": "Priority Sorting", "desc": "Organize files based on usage patterns and importance."},
            {"icon": "images/feature_card/advance_search.png", "title": "Advanced Search", "desc": "Powerful filtering to find exactly what you're looking for."},
            {"icon": "images/feature_card/customizable_rule.png", "title": "Customizable Rules", "desc": "Create personalized organization rules that work for you."}
        ]

        # Add feature cards to grid - 3 per row
        for i, feature in enumerate(feature_data):
            row, col = divmod(i, 3)
            card = FeatureCard(feature["icon"], feature["title"], feature["desc"])
            features_grid.addWidget(card, row, col)

        features_layout.addLayout(features_grid)
        content_layout.addWidget(features_section)
        
        # Action section
        action_section = QFrame()
        action_layout = QVBoxLayout(action_section)
        action_layout.setContentsMargins(0, 0, 0, 0)
        
        action_title = QLabel("Get Started")
        action_title.setObjectName("sectionTitle")
        action_layout.addWidget(action_title)
        
        action_container = QWidget()
        action_container_layout = QHBoxLayout(action_container)
        action_container_layout.setContentsMargins(0, 20, 0, 0)
        action_container_layout.setSpacing(15)
        
        # Action cards
        # In your setup_dashboard_page method, modify the ActionCard creation:
        scan_card = ActionCard(
            "images/action_card/system_scan.png", 
            "Scan System", 
            "Run a comprehensive scan to analyze your files", 
            "Start Scan"
        )
        scan_card.setObjectName("scanCard")
        # Add shadow effect
        shadow = QGraphicsDropShadowEffect()
        shadow.setBlurRadius(15)
        shadow.setXOffset(0)
        shadow.setYOffset(5)
        shadow.setColor(QColor(0, 0, 0, 30))
        scan_card.setGraphicsEffect(shadow)
        scan_card.action_btn.clicked.connect(self.start_system_scan)

        duplicates_card = ActionCard(
            "images/action_card/duplicate_detection.png", 
            "Find Duplicates", 
            "Identify and manage duplicate files safely", 
            "Find Now"
        )
        duplicates_card.setObjectName("duplicatesCard")
        # Add shadow effect
        shadow = QGraphicsDropShadowEffect()
        shadow.setBlurRadius(15)
        shadow.setXOffset(0)
        shadow.setYOffset(5)
        shadow.setColor(QColor(0, 0, 0, 30))
        duplicates_card.setGraphicsEffect(shadow)
        duplicates_card.action_btn.clicked.connect(self.find_duplicates)

        folders_card = ActionCard(
            "images/action_card/folder_scan.png", 
            "Select Folders", 
            "Choose which locations to monitor and organize", 
            "Select Folders"
        )
        folders_card.setObjectName("foldersCard")
        # Add shadow effect
        shadow = QGraphicsDropShadowEffect()
        shadow.setBlurRadius(15)
        shadow.setXOffset(0)
        shadow.setYOffset(5)
        shadow.setColor(QColor(0, 0, 0, 30))
        folders_card.setGraphicsEffect(shadow)
        folders_card.action_btn.clicked.connect(self.select_folders)

        action_container_layout.addWidget(scan_card)
        action_container_layout.addWidget(duplicates_card)
        action_container_layout.addWidget(folders_card)

        action_layout.addWidget(action_container)
        content_layout.addWidget(action_section)
        
        scroll_area.setWidget(content_widget)
        
        # Dashboard layout
        dashboard_layout = QVBoxLayout(self.dashboard_page)
        dashboard_layout.setContentsMargins(0, 0, 0, 0)
        dashboard_layout.addWidget(scroll_area)
    
    def setup_files_page(self):
        # Main layout for files page
        layout = QVBoxLayout(self.files_page)
        layout.setContentsMargins(20, 20, 20, 20)
        layout.setSpacing(15)
        
        # Title and controls
        title_frame = QFrame()
        title_layout = QHBoxLayout(title_frame)
        
        title_label = QLabel("File Management")
        title_label.setObjectName("sectionTitle")
        
        self.refresh_btn = QPushButton("Refresh")
        self.refresh_btn.setObjectName("actionBtn")
        self.refresh_btn.clicked.connect(self.refresh_file_view)
        
        title_layout.addWidget(title_label)
        title_layout.addStretch()
        title_layout.addWidget(self.refresh_btn)
        
        layout.addWidget(title_frame)
        
        # File list
        self.file_list = FileListWidget()
        self.file_list.setObjectName("fileList")
        
        # Add context menu actions
        self.setup_file_list_context_menu()
        
        layout.addWidget(self.file_list)
        
        # Show the current view
        if self.current_priority_view:
            self.show_priority_files(self.current_priority_view)
        elif self.current_duplicates:
            self.show_duplicates_results(self.current_duplicates)
    
    def setup_file_list_context_menu(self):
        """Setup context menu for file list"""
        self.file_list.setContextMenuPolicy(Qt.CustomContextMenu)
        self.file_list.customContextMenuRequested.connect(self.show_file_list_context_menu)
    
    def show_file_list_context_menu(self, position):
        """Show context menu for file list"""
        menu = QMenu()
        
        open_action = QAction("Open File", self)
        open_action.triggered.connect(self.open_selected_file)
        menu.addAction(open_action)
        
        show_in_folder_action = QAction("Show in Folder", self)
        show_in_folder_action.triggered.connect(self.show_selected_file_in_folder)
        menu.addAction(show_in_folder_action)
        
        delete_action = QAction("Delete", self)
        delete_action.triggered.connect(self.delete_selected_files)
        menu.addAction(delete_action)
        
        menu.exec_(self.file_list.viewport().mapToGlobal(position))
    
    def open_selected_file(self):
        """Open the selected file"""
        selected_items = self.file_list.selectedItems()
        if selected_items:
            file_path = selected_items[0].data(Qt.UserRole)
            try:
                if sys.platform == "win32":
                    os.startfile(file_path)
                elif sys.platform == "darwin":
                    os.system(f"open '{file_path}'")
                else:
                    os.system(f"xdg-open '{file_path}'")
            except Exception as e:
                QMessageBox.warning(self, "Error", f"Could not open file: {e}")
    
    def show_selected_file_in_folder(self):
        """Show the selected file in its folder"""
        selected_items = self.file_list.selectedItems()
        if selected_items:
            file_path = selected_items[0].data(Qt.UserRole)
            try:
                if sys.platform == "win32":
                    os.startfile(os.path.dirname(file_path))
                elif sys.platform == "darwin":
                    os.system(f"open '{os.path.dirname(file_path)}'")
                else:
                    os.system(f"xdg-open '{os.path.dirname(file_path)}'")
            except Exception as e:
                QMessageBox.warning(self, "Error", f"Could not open folder: {e}")
    
    def delete_selected_files(self):
        """Delete selected files"""
        selected_items = self.file_list.selectedItems()
        if not selected_items:
            return
            
        reply = QMessageBox.question(
            self, 
            "Confirm Deletion",
            f"Are you sure you want to delete {len(selected_items)} file(s)?",
            QMessageBox.Yes | QMessageBox.No,
            QMessageBox.No
        )
        
        if reply == QMessageBox.Yes:
            for item in selected_items:
                file_path = item.data(Qt.UserRole)
                try:
                    os.remove(file_path)
                    self.file_list.takeItem(self.file_list.row(item))
                except Exception as e:
                    QMessageBox.warning(self, "Error", f"Could not delete {file_path}: {e}")

    def setup_settings_page(self):
        # Main layout for settings page
        layout = QVBoxLayout(self.settings_page)
        layout.setContentsMargins(30, 30, 30, 30)
        layout.setSpacing(25)
        
        # Title with 3D effect
        title_label = QLabel("⚙️ SETTINGS")
        title_label.setObjectName("settingsTitle")
        title_label.setAlignment(Qt.AlignCenter)
        layout.addWidget(title_label)
        
        # Add decorative divider
        divider = QFrame()
        divider.setFrameShape(QFrame.HLine)
        divider.setFrameShadow(QFrame.Sunken)
        divider.setStyleSheet("border: none; border-top: 1px dashed #6C5CE7; margin: 10px 0;")
        layout.addWidget(divider)
        
        # Monitored folders section - Card with 3D effect
        folders_card = QFrame()
        folders_card.setObjectName("settingsCard")
        folders_layout = QVBoxLayout(folders_card)
        folders_layout.setContentsMargins(20, 20, 20, 20)
        folders_layout.setSpacing(15)
        
        # Section header with icon
        folders_header = QHBoxLayout()
        folders_icon = QLabel("📁")
        folders_icon.setObjectName("sectionIcon")
        folders_title = QLabel("MONITORED FOLDERS")
        folders_title.setObjectName("settingsSectionTitle")
        folders_header.addWidget(folders_icon)
        folders_header.addWidget(folders_title)
        folders_header.addStretch()
        folders_layout.addLayout(folders_header)
        
        # Folder list with modern styling
        self.folders_list = QListWidget()
        self.folders_list.setObjectName("foldersList3D")
        self.folders_list.setMinimumHeight(200)
        self.update_folders_list()
        
        # Button container with 3D effect
        btn_container = QFrame()
        btn_container.setObjectName("buttonContainer")
        folders_btn_layout = QHBoxLayout(btn_container)
        folders_btn_layout.setContentsMargins(10, 10, 10, 10)
        
        # 3D-style buttons
        add_folder_btn = QPushButton("➕ Add Folder")
        add_folder_btn.setObjectName("actionBtn3D")
        add_folder_btn.clicked.connect(self.select_folders)
        
        remove_folder_btn = QPushButton("🗑️ Remove Selected")
        remove_folder_btn.setObjectName("dangerBtn3D")
        remove_folder_btn.clicked.connect(self.remove_selected_folder)
        
        folders_btn_layout.addWidget(add_folder_btn)
        folders_btn_layout.addWidget(remove_folder_btn)
        
        folders_layout.addWidget(self.folders_list)
        folders_layout.addWidget(btn_container)
        layout.addWidget(folders_card)
        
        # Add another decorative divider
        divider2 = QFrame()
        divider2.setFrameShape(QFrame.HLine)
        divider2.setFrameShadow(QFrame.Sunken)
        divider2.setStyleSheet("border: none; border-top: 1px dashed #6C5CE7; margin: 10px 0;")
        layout.addWidget(divider2)
        
        # Scan settings section - Card with 3D effect
        scan_card = QFrame()
        scan_card.setObjectName("settingsCard")
        scan_layout = QVBoxLayout(scan_card)
        scan_layout.setContentsMargins(20, 20, 20, 20)
        scan_layout.setSpacing(15)
        
        # Section header with icon
        scan_header = QHBoxLayout()
        scan_icon = QLabel("⏱️")
        scan_icon.setObjectName("sectionIcon")
        scan_title = QLabel("SCAN SETTINGS")
        scan_title.setObjectName("settingsSectionTitle")
        scan_header.addWidget(scan_icon)
        scan_header.addWidget(scan_title)
        scan_header.addStretch()
        scan_layout.addLayout(scan_header)
        
        # Modern form layout
        form_layout = QFormLayout()
        form_layout.setVerticalSpacing(15)
        form_layout.setHorizontalSpacing(20)
        
        auto_scan_label = QLabel("Automatic Scan Interval:")
        auto_scan_label.setObjectName("formLabel")
        
        self.auto_scan_spinbox = QSpinBox()
        self.auto_scan_spinbox.setObjectName("spinBox3D")
        self.auto_scan_spinbox.setRange(1, 24)
        self.auto_scan_spinbox.setValue(DEFAULT_SCAN_INTERVAL // 3600)
        
        # Add units label
        units_label = QLabel("hours")
        units_label.setObjectName("unitsLabel")
        
        hbox = QHBoxLayout()
        hbox.addWidget(self.auto_scan_spinbox)
        hbox.addWidget(units_label)
        hbox.addStretch()
        
        form_layout.addRow(auto_scan_label, hbox)
        scan_layout.addLayout(form_layout)
        
        # Save button with 3D effect
        save_settings_btn = QPushButton("💾 SAVE SETTINGS")
        save_settings_btn.setObjectName("saveBtn3D")
        save_settings_btn.clicked.connect(self.save_settings)
        scan_layout.addWidget(save_settings_btn, alignment=Qt.AlignCenter)
        
        layout.addWidget(scan_card)
        layout.addStretch()
    
    def create_divider(self):
        """Create a decorative divider line"""
        divider = QFrame()
        divider.setFrameShape(QFrame.HLine)
        divider.setFrameShadow(QFrame.Sunken)
        divider.setStyleSheet("""
            QFrame {
                border: none;
                border-top: 1px dashed #6C5CE7;
                margin: 10px 0;
            }
            .dark QFrame {
                border-top: 1px dashed #00CEC9;
            }
        """)
        return divider
    
    def setup_footer(self):
        self.footer_frame = QFrame()
        self.footer_frame.setObjectName("footerFrame")
        self.footer_frame.setMinimumHeight(60)
        
        footer_layout = QHBoxLayout(self.footer_frame)
        footer_layout.setContentsMargins(20, 0, 20, 0)
        
        # Logo container
        logo_container = QWidget()
        logo_layout = QHBoxLayout(logo_container)
        logo_layout.setContentsMargins(0, 0, 0, 0)
        
        logo = QLabel()
        try:
            logo_pixmap = QPixmap("images/intelliclean-logo.png")
            logo.setPixmap(logo_pixmap.scaled(24, 24, Qt.KeepAspectRatio, Qt.SmoothTransformation))
        except Exception:
            # Fallback if logo not found
            logo.setText("IC")
            logo.setStyleSheet("font-weight: bold; font-size: 12px; color: white; background-color: transparent; border-radius: 12px;")
            logo.setAlignment(Qt.AlignCenter)
            logo.setFixedSize(24, 24)
        
        copyright_text = QLabel("IntelliClean © 2025")
        copyright_text.setObjectName("copyrightText")
        
        logo_layout.addWidget(logo)
        logo_layout.addWidget(copyright_text)
        
        # Links container
        links_container = QWidget()
        links_layout = QHBoxLayout(links_container)
        links_layout.setContentsMargins(0, 0, 0, 0)
        links_layout.setSpacing(15)
        
        link_texts = ["Privacy Policy", "Terms of Service", "Help & Support", "Contact"]
        for text in link_texts:
            link = QPushButton(text)
            link.setObjectName("footerLink")
            link.setFlat(True)
            links_layout.addWidget(link)
        
        # Social icons
        social_container = QWidget()
        social_layout = QHBoxLayout(social_container)
        social_layout.setContentsMargins(0, 0, 0, 0)
        social_layout.setSpacing(10)
        
        social_icons = ["twitter", "facebook", "linkedin", "github"]
        for icon_name in social_icons:
            icon_btn = IconButton(icon_name=icon_name, size=36)
            icon_btn.setObjectName("socialIcon")
            social_layout.addWidget(icon_btn)
        
        footer_layout.addWidget(logo_container)
        footer_layout.addStretch()
        footer_layout.addWidget(links_container)
        footer_layout.addStretch()
        footer_layout.addWidget(social_container)
    
    def load_icons(self):
        # This method would load any custom icons needed for the app
        # The icon_provider will handle this
        pass
    
    def connect_signals(self):
        # Connect signals and slots
        self.file_manager.scan_complete.connect(self.update_dashboard_stats)
        self.file_manager.duplicate_scan_complete.connect(self.show_duplicates_results)
        self.file_manager.folder_added.connect(self.on_folder_added)
        self.file_manager.folder_removed.connect(self.on_folder_removed)
        self.file_manager.ai_training_complete.connect(self.on_ai_training_complete)
        self.file_manager.scan_complete.connect(self.analytics_page.update_analytics)
    
    def nav_button_clicked(self, button):
        # Update button styles
        for btn in self.nav_buttons:
            btn.setProperty("active", False)
            btn.setStyle(btn.style().unpolish(btn))
            btn.setStyle(btn.style().polish(btn))
        
        button.setProperty("active", True)
        button.setStyle(button.style().unpolish(button))
        button.setStyle(button.style().polish(button))
        
        # Switch page
        self.stacked_widget.setCurrentIndex(button.page_index)
    
    def toggle_theme(self):
        self.is_dark_theme = not self.is_dark_theme

        # Set icon based on theme state
        if self.is_dark_theme:
            self.theme_btn.setIcon(QIcon("images/toggle-icon-light.png"))  # sun icon
        else:
            self.theme_btn.setIcon(QIcon("images/toggle-icon-dark.png"))  # moon icon

        self.apply_stylesheet()
    
    def apply_stylesheet(self):
        """Apply the application stylesheet from file or fallback to inline styles"""
        print(f"Applying {'dark' if self.is_dark_theme else 'light'} theme stylesheet...")
        
        # Set the theme class on the main window
        self.setProperty("class", "dark" if self.is_dark_theme else "")
        
        # Try to load from file first
        stylesheet_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "style.qss")
        
        try:
            with open(stylesheet_path, "r") as file:
                stylesheet = file.read()
                # Apply the stylesheet with theme-specific adjustments
                self.setStyleSheet(stylesheet)
                return
        except FileNotFoundError:
            print(f"Could not find stylesheet file at {stylesheet_path}, using inline styles")
        
        # Fallback to inline stylesheet
        if self.is_dark_theme:
            bg_color = "#1e1e2e"  # Dark background
            text_color = "#e6e8ee"  # Light text
            card_bg = "#282a36"  # Slightly lighter than background
            border_color = "#3a3e52"  # Dark border
            accent_color = "#4a6bff"  # Accent color (blue)
            header_footer_bg = "#23252e"  # Slightly darker than main background
        else:
            bg_color = "#f8f9fd"  # Light background
            text_color = "#333333"  # Dark text
            card_bg = "#ffffff"  # White cards
            border_color = "#e6e8ee"  # Light border
            accent_color = "#4a6bff"  # Same accent color
            header_footer_bg = "#ffffff"  # White header/footer
        
        stylesheet = f"""
            /* Base styles */
            QMainWindow, QScrollArea, QStackedWidget, QWidget {{
                background-color: {bg_color};
                color: {text_color};
            }}
            
            /* Header and footer */
            QFrame#headerFrame, QFrame#footerFrame {{
                background-color: {header_footer_bg};
            }}
            
            QFrame#headerFrame {{
                border-bottom: 1px solid {border_color};
            }}
            
            QFrame#footerFrame {{
                border-top: 1px solid {border_color};
            }}
            
            /* Navigation buttons */
            QPushButton#navButton {{
                background-color: transparent;
                color: {text_color};
                border: none;
                border-radius: 20px;
                padding: 8px 16px;
                font-weight: 500;
            }}
            
            QPushButton#navButton:hover {{
                background-color: rgba(74, 107, 255, 0.1);
            }}
            
            QPushButton#navButton[active="true"] {{
                background-color: {accent_color};
                color: white;
            }}
            
            /* Section titles */
            QLabel#sectionTitle {{
                font-size: 24px;
                font-weight: bold;
                color: {text_color};
            }}
            
            /* Cards */
            StatCard, PriorityCard, FeatureCard, ActionCard {{
                background-color: {card_bg};
                border: 1px solid {border_color};
            }}
            
            /* Progress dialog */
            ProgressDialog {{
                background-color: {card_bg};
            }}
            
            QProgressBar {{
                border: 1px solid {border_color};
            }}
            
            QProgressBar::chunk {{
                background-color: {accent_color};
            }}
            
            /* File list */
            QListWidget {{
                background-color: {card_bg};
                border: 1px solid {border_color};
                color: {text_color};
            }}
            
            QListWidget::item {{
                border-bottom: 1px solid {border_color};
            }}
            
            QListWidget::item:hover {{
                background-color: {bg_color};
            }}
            
            QListWidget::item:selected {{
                background-color: {accent_color};
                color: white;
            }}
            
            /* Settings sections */
            QFrame#settingsSection {{
                background-color: {card_bg};
                border: 1px solid {border_color};
            }}
            
            /* Text colors */
            QLabel {{
                color: {text_color};
            }}
        """
        
        self.setStyleSheet(stylesheet)
    
    @pyqtSlot()
    def start_system_scan(self):
        if not self.file_manager.monitored_folders:
            QMessageBox.warning(
                self, 
                "No Folders Selected", 
                "Please select folders to scan first."
            )
            self.select_folders()
            return
        
        if self.file_manager.file_data:
            reply = QMessageBox.question(
                self,
                "Rescan System?",
                "File data already exists. Would you like to rescan all folders?",
                QMessageBox.Yes | QMessageBox.No,
                QMessageBox.No
            )
            force_rescan = (reply == QMessageBox.Yes)
        else:
            force_rescan = True
        
        self.progress_dialog = ProgressDialog("System Scan", "Preparing to analyze files...", self)
        self.progress_dialog.cancel_btn.clicked.connect(self.cancel_scan)
        
        self.scan_thread = ScanThread(self.file_manager, force_rescan)
        
        # Connect signals - only use progress_update
        self.scan_thread.progress_update.connect(self.progress_dialog.update_progress)
        self.scan_thread.scan_complete.connect(self.on_scan_complete)
        self.scan_thread.finished.connect(self.cleanup_scan_thread)
        
        # Show dialog and start thread
        self.progress_dialog.show()
        self.scan_thread.start()

    def cancel_scan(self):
        if hasattr(self, 'scan_thread') and self.scan_thread.isRunning():
            self.scan_thread.stop()
            self.progress_dialog.update_status("Cancelling scan...")
            if not self.scan_thread.wait(2000):  # Wait up to 2 seconds
                self.scan_thread.terminate()
        self.progress_dialog.close()

    def cleanup_scan_thread(self):
        if hasattr(self, 'scan_thread'):
            try:
                self.scan_thread.progress_update.disconnect()
                self.scan_thread.scan_complete.disconnect()
            except:
                pass
            self.scan_thread.quit()
            self.scan_thread.wait(500)
            self.scan_thread.deleteLater()
            del self.scan_thread
    def on_scan_complete(self, result):
        self.progress_dialog.accept()
        if result:  # Only update if we got a result (not cancelled)
            self.update_dashboard_stats(result)
    
    
    @pyqtSlot()
    def find_duplicates(self):
        # Check if we have scanned files
        if not self.file_manager.file_data:
            reply = QMessageBox.question(
                self,
                "Scan Required",
                "A system scan is required before finding duplicates. Do you want to scan now?",
                QMessageBox.Yes | QMessageBox.No,
                QMessageBox.Yes
            )
            
            if reply == QMessageBox.Yes:
                self.start_system_scan()
            return
        
        # Create and start the progress dialog
        self.progress_dialog = ProgressDialog("Finding Duplicates", "Preparing to analyze file contents...", self)
        
        # Create duplicate search thread
        self.duplicate_thread = ScanThread(self.file_manager, scan_type="duplicates")
        
        # Connect signals
        self.file_manager.scan_progress.connect(self.progress_dialog.update_progress)
        self.duplicate_thread.duplicate_scan_complete.connect(self.progress_dialog.accept)
        self.duplicate_thread.duplicate_scan_complete.connect(self.show_duplicates_results)
        self.duplicate_thread.finished.connect(self.duplicate_thread.deleteLater)
        
        # Show dialog and start thread
        self.progress_dialog.show()
        self.duplicate_thread.start()

    @pyqtSlot(int, int, str)
    def update_duplicate_progress(self, current, total, status):
        if hasattr(self, 'progress_dialog') and self.progress_dialog:
            self.progress_dialog.update_progress(current, total, status)
    def cancel_duplicate_scan(self):
        if hasattr(self, 'duplicate_thread') and self.duplicate_thread.isRunning():
            self.duplicate_thread.stop()
            if hasattr(self, 'progress_dialog'):
                self.progress_dialog.update_status("Cancelling...")
                QApplication.processEvents()
        
        if hasattr(self, 'progress_dialog'):
            self.progress_dialog.close()

    def cleanup_duplicate_thread(self):
        if hasattr(self, 'duplicate_thread'):
            try:
                self.duplicate_thread.progress_update.disconnect()
                self.duplicate_thread.duplicate_scan_complete.disconnect()
            except:
                pass
            
            if self.duplicate_thread.isRunning():
                self.duplicate_thread.quit()
                self.duplicate_thread.wait(2000)
            
            self.duplicate_thread.deleteLater()
            del self.duplicate_thread
        
        if hasattr(self, 'progress_dialog'):
            self.progress_dialog.deleteLater()
            del self.progress_dialog

    @pyqtSlot(list)
    def on_duplicate_scan_complete(self, duplicates):
        if hasattr(self, 'progress_dialog'):
            self.progress_dialog.accept()
        
        if duplicates:
            self.show_duplicates_results(duplicates)
        else:
            QMessageBox.information(
                self,
                "No Duplicates Found",
                "No duplicate files were found in the monitored folders."
            )
    @pyqtSlot()
    def select_folders(self):
        folder = QFileDialog.getExistingDirectory(
            self, 
            "Select Folder to Monitor",
            os.path.expanduser("~"),
            QFileDialog.ShowDirsOnly | QFileDialog.DontResolveSymlinks
        )
        
        if folder:
            if self.file_manager.add_monitored_folder(folder):
                self.update_folders_list()
                QMessageBox.information(
                    self,
                    "Folder Added",
                    f"Added {folder} to monitored folders."
                )
                # Start scan after adding new folder
                self.start_system_scan()
    
    @pyqtSlot()
    def remove_selected_folder(self):
        selected_items = self.folders_list.selectedItems()
        if not selected_items:
            return
            
        folder_path = selected_items[0].text()
        if self.file_manager.remove_monitored_folder(folder_path):
            self.update_folders_list()
            QMessageBox.information(
                self,
                "Folder Removed",
                f"Removed {folder_path} from monitored folders."
            )
    
    @pyqtSlot(str)
    def on_folder_added(self, folder_path):
        self.update_folders_list()
    
    @pyqtSlot(str)
    def on_folder_removed(self, folder_path):
        self.update_folders_list()
    
    def update_folders_list(self):
        """Update the list of monitored folders in settings"""
        self.folders_list.clear()
        for folder in self.file_manager.monitored_folders:
            self.folders_list.addItem(folder)
    
    @pyqtSlot(dict)
    def update_dashboard_stats(self, stats):
        # Update stat cards
        self.stat_cards[0].update_data(str(stats["duplicates"]), "files found")
        self.stat_cards[1].update_data(str(stats["unused_files"]), "files identified")
        self.stat_cards[2].update_data(f"{stats['potential_savings']} GB", "potential")
        self.stat_cards[3].update_data(str(stats["total_files"]), "files total")
        
        # Update priority cards - with safe division
        total_files = max(1, stats["total_files"])  # Prevent division by zero
        
        self.priority_cards["high"].update_data(
            f"{stats['priorities']['high']} files", 
            min(100, int(stats['priorities']['high'] * 100 / total_files))
        )
        self.priority_cards["medium"].update_data(
            f"{stats['priorities']['medium']} files",
            min(100, int(stats['priorities']['medium'] * 100 / total_files))
        )
        self.priority_cards["low"].update_data(
            f"{stats['priorities']['low']} files",
            min(100, int(stats['priorities']['low'] * 100 / total_files))
        )
    
    @pyqtSlot(list)
    def show_duplicates_results(self, duplicates):
        self.current_duplicates = duplicates
        self.current_priority_view = None
        
        if not duplicates:
            QMessageBox.information(
                self,
                "No Duplicates Found",
                "No duplicate files were found in the monitored folders."
            )
            return
        
        # Switch to files page
        self.nav_button_clicked(self.nav_buttons[1])
        
        # Clear and populate file list
        self.file_list.clear()
        
        # Add each duplicate group to the list
        for dup_group in duplicates:
            # Add a separator item for each group
            separator = QListWidgetItem(f"Duplicate Group ({len(dup_group['files'])} files, {self.file_manager._format_size(dup_group['size'])})")
            separator.setFlags(separator.flags() & ~Qt.ItemIsSelectable)
            separator.setBackground(QColor("#f0f0f0"))
            self.file_list.addItem(separator)
            
            # Add each file in the group
            for file_path in dup_group["files"]:
                file_info = self.file_manager.get_file_info(file_path)
                item = QListWidgetItem(f"{file_info['name']} - {file_info['size_str']} - {file_info['last_access_str']}")
                item.setData(Qt.UserRole, file_path)
                self.file_list.addItem(item)
    
    def show_priority_files(self, priority_level):
        self.current_priority_view = priority_level
        self.current_duplicates = []
        
        # Switch to files page
        self.nav_button_clicked(self.nav_buttons[1])
        
        # Clear and populate file list
        self.file_list.clear()
        
        files = self.file_manager.get_priority_files(priority_level)
        if not files:
            QMessageBox.information(
                self,
                f"No {priority_level.capitalize()} Priority Files",
                f"No {priority_level} priority files were found."
            )
            return
        
        for file_path in files:
            file_info = self.file_manager.get_file_info(file_path)
            item = QListWidgetItem(f"{file_info['name']} - {file_info['size_str']} - {file_info['last_access_str']}")
            item.setData(Qt.UserRole, file_path)
            self.file_list.addItem(item)
    
    @pyqtSlot()
    def refresh_file_view(self):
        if self.current_priority_view:
            self.show_priority_files(self.current_priority_view)
        elif self.current_duplicates:
            self.show_duplicates_results(self.current_duplicates)
        else:
            self.file_list.clear()
    
    @pyqtSlot(bool)
    def on_ai_training_complete(self, success):
        if success:
            QMessageBox.information(
                self,
                "AI Training Complete",
                "The AI model has finished analyzing your files and updated priorities."
            )
        else:
            QMessageBox.warning(
                self,
                "AI Training Failed",
                "The AI model encountered an error while analyzing your files."
            )
    
    @pyqtSlot()
    def save_settings(self):
        # Save scan interval
        scan_interval_hours = self.auto_scan_spinbox.value()
        # TODO: Implement automatic scanning with this interval
        
        QMessageBox.information(
            self,
            "Settings Saved",
            f"Settings have been saved. Automatic scan interval set to {scan_interval_hours} hours."
        )

if __name__ == "__main__":
    app = QApplication(sys.argv)
    app.setStyle('Fusion')  # For consistent look across platforms
    
    # Set application information
    app.setApplicationName("IntelliClean")
    app.setApplicationVersion("1.0")
    app.setOrganizationName("IntelliSoft")
    
    window = IntelliCleanUI()
    window.show()
    sys.exit(app.exec_())